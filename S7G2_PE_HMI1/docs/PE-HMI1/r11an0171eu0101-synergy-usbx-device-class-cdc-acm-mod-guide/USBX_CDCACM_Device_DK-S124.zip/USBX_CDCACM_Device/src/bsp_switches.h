/* generated bsp_swicthes header file - do not edit */

#include "r_ioport.h"

#define PUSH_BUTTON_S1       IOPORT_PORT_02_PIN_06
#define PUSH_BUTTON_S2       IOPORT_PORT_00_PIN_04
#define PUSH_BUTTON_START    (1)
#define PUSH_BUTTON_END      (2)
#define PUSH_BUTTON_COUNT    ((PUSH_BUTTON_END) - (PUSH_BUTTON_START)+1)
#define MULTI_COLOR			 (0)

/* Array to point to the IO-pins */
ioport_port_pin_t p_switches[PUSH_BUTTON_COUNT] = {PUSH_BUTTON_S1,PUSH_BUTTON_S2};
