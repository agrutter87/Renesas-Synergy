/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/**
 * Application Description:
 *
 * The application project demonstrates the typical use of USBX
 * video class. The application project main thread entry checks
 * the spec supported by the connected camera and displays
 * information on format types, frame resolutions, and intervals
 * to the debugging console.
 *
 * Also, main thread entry receives semaphore notification from
 * the user callback function of video class. The user callback
 * function of video class is called when an image frame is received
 * from camera.
 **/
#include "camera_thread.h"

#ifdef SEMI_HOSTING
#include "stdio.h"
#ifdef __GNUC__
void initialise_monitor_handles(void);
#endif
#endif

/* Class name of video class */
extern UCHAR _ux_system_host_class_video_name[];

/***********************************************************************************************************************
    Private function prototypes
 ***********************************************************************************************************************/
VOID uvc_transfer_request_done_callback(UX_TRANSFER * transfer_request);

VOID uvc_parameter_interval_list(UX_HOST_CLASS_VIDEO *video);
UINT uvc_parameter_frame_list(UX_HOST_CLASS_VIDEO *video);
VOID uvc_parameter_list(UX_HOST_CLASS_VIDEO *video);

VOID uvc_process_function(UX_HOST_CLASS_VIDEO* video);

/***********************************************************************************************************************
    Private global variables
 ***********************************************************************************************************************/
#define EVENTFLAG_USB_DEVICE_INSERTED   0x01

/* Define the number of buffers used in this demo. */ 
#define MAX_NUM_BUFFERS  2 

/* video class instance */
UX_HOST_CLASS_VIDEO* volatile video_host_class;

/* video buffer */
UCHAR video_buffer[10*1024];

/* Name string of VS types */
struct 
{
    int type;
    char* name;
} vs_type_name[] =
{
    { UX_HOST_CLASS_VIDEO_VS_UNDEFINED,             "UX_HOST_CLASS_VIDEO_VS_UNDEFINED"             },
    { UX_HOST_CLASS_VIDEO_VS_INPUT_HEADER,          "UX_HOST_CLASS_VIDEO_VS_INPUT_HEADER"          },
    { UX_HOST_CLASS_VIDEO_VS_OUTPUT_HEADER,         "UX_HOST_CLASS_VIDEO_VS_OUTPUT_HEADER"         },
    { UX_HOST_CLASS_VIDEO_VS_STILL_IMAGE_FRAME,     "UX_HOST_CLASS_VIDEO_VS_STILL_IMAGE_FRAME"     },
    { UX_HOST_CLASS_VIDEO_VS_FORMAT_UNCOMPRESSED,   "UX_HOST_CLASS_VIDEO_VS_FORMAT_UNCOMPRESSED"   },
    { UX_HOST_CLASS_VIDEO_VS_FRAME_UNCOMPRESSED,    "UX_HOST_CLASS_VIDEO_VS_FRAME_UNCOMPRESSED"    },
    { UX_HOST_CLASS_VIDEO_VS_FORMAT_MJPEG,          "UX_HOST_CLASS_VIDEO_VS_FORMAT_MJPEG"          },
    { UX_HOST_CLASS_VIDEO_VS_FRAME_MJPEG,           "UX_HOST_CLASS_VIDEO_VS_FRAME_MJPEG"           },
    { UX_HOST_CLASS_VIDEO_VS_FORMAT_MPEG2TS,        "UX_HOST_CLASS_VIDEO_VS_FORMAT_MPEG2TS"        },
    { UX_HOST_CLASS_VIDEO_VS_FORMAT_DV,             "UX_HOST_CLASS_VIDEO_VS_FORMAT_DV"             },
    { UX_HOST_CLASS_VIDEO_VS_COLORFORMAT,           "UX_HOST_CLASS_VIDEO_VS_COLORFORMAT"           },
    { UX_HOST_CLASS_VIDEO_VS_FORMAT_FRAME_BASED,    "UX_HOST_CLASS_VIDEO_VS_FORMAT_FRAME_BASED"    },
    { UX_HOST_CLASS_VIDEO_VS_FRAME_FRAME_BASED,     "UX_HOST_CLASS_VIDEO_VS_FRAME_FRAME_BASED"     },
    { UX_HOST_CLASS_VIDEO_VS_FORMAT_STREAM_BASED,   "UX_HOST_CLASS_VIDEO_VS_FORMAT_STREAM_BASED"   }
};


/* USBX Host event notification callback function */
UINT ux_host_usr_event_notification(ULONG event, UX_HOST_CLASS * host_class, VOID * instance)
{

    if (UX_SUCCESS
            == _ux_utility_memory_compare (_ux_system_host_class_video_name, host_class,
                                           _ux_utility_string_length_get(_ux_system_host_class_video_name)))
    {
        if (UX_DEVICE_INSERTION == event) /* Check if there is a device insertion. */
        {
            video_host_class = instance;

            /* Set the event flag to let application know the device insertion. */
            tx_event_flags_set (&g_device_insert_eventflag, EVENTFLAG_USB_DEVICE_INSERTED, TX_OR);
        }
        else if(UX_DEVICE_REMOVAL == event)
        {
            /* Clear the event flag in case the camera was removed before the application could clear it. */
            tx_event_flags_set (&g_device_insert_eventflag, (ULONG)~EVENTFLAG_USB_DEVICE_INSERTED, TX_AND);

            video_host_class = NULL;
        }
    }

    return UX_SUCCESS;
}


/* Video data received callback function. */ 
VOID uvc_transfer_request_done_callback(UX_TRANSFER * transfer_request)
{
    /* This is the callback function invoked by UVC class after a packet of 
       data is received. */

    /* The actual number of bytes being received into the data buffer is 
       recorded in tranfer_request -> ux_transfer_request_actual_length. */ 

    /* Since this callback function executes in the USB host controller
       thread, a semaphore is released so the application can pick up the 
       video data in application thread. */

    SSP_PARAMETER_NOT_USED(transfer_request);

    tx_semaphore_put(&g_data_received_semaphore); 
} 


/* Show the interval types */
VOID uvc_parameter_interval_list(UX_HOST_CLASS_VIDEO *video)
{
    UX_HOST_CLASS_VIDEO_FRAME_DESCRIPTOR frame_descriptor;

    ULONG min_frame_interval;
    ULONG max_frame_interval;
    ULONG frame_interval_step;
    int i;

    /* Make the descriptor machine independent.  */
    _ux_utility_descriptor_parse(video -> ux_host_class_video_current_frame_address,
                                 _ux_system_class_video_frame_descriptor_structure,
                                 UX_HOST_CLASS_VIDEO_FRAME_DESCRIPTOR_ENTRIES, (UCHAR *) &frame_descriptor);

    /* Check the frame interval type.  */
    if (frame_descriptor.bFrameIntervalType == 0)
    {
        /* Frame interval type is continuous.  */
        min_frame_interval = _ux_utility_long_get(video -> ux_host_class_video_current_frame_address + 26);
        max_frame_interval = _ux_utility_long_get(video -> ux_host_class_video_current_frame_address + 30);
        frame_interval_step = _ux_utility_long_get(video -> ux_host_class_video_current_frame_address + 34);

        SSP_PARAMETER_NOT_USED(min_frame_interval);
        SSP_PARAMETER_NOT_USED(max_frame_interval);
        SSP_PARAMETER_NOT_USED(frame_interval_step);

#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf("        interval min:%d, max:%d, step:%d\n",
                   (int)min_frame_interval,
                   (int)max_frame_interval,
                   (int)frame_interval_step);
        }
#endif
    }
    else
    {
#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf("        interval ");

            /* Frame interval type is discrete.  */
            for(i = 0; i < (int)frame_descriptor.bFrameIntervalType; i++)
            {
                printf("%d", (int)_ux_utility_long_get(video -> ux_host_class_video_current_frame_address + 26 + (unsigned int)i * sizeof(ULONG)));

                if((unsigned int)(i+1)<frame_descriptor.bFrameIntervalType)
                {
                    printf(", ");
                }
                else
                {
                    printf("\n");
                }
            }
        }
#endif
    }
}


/* Show the frame resolutions */
UINT uvc_parameter_frame_list(UX_HOST_CLASS_VIDEO *video)
{
    ULONG frame_index;
    UX_HOST_CLASS_VIDEO_PARAMETER_FRAME_DATA frame_parameter;

    UINT status = UX_SUCCESS;

    /* frame resolutions */
#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("    --- frame resolutions\n");
    }
#endif

    for (frame_index = 1; frame_index <= video -> ux_host_class_video_number_frames; frame_index++)
    {
        /* Get frame data for current frame index.  */
        frame_parameter.ux_host_class_video_parameter_frame_requested = frame_index;
        status = _ux_host_class_video_frame_data_get(video, &frame_parameter);
        if (status != UX_SUCCESS)
        {
            return(status);
        }

#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            /* Show the frame resolution  */
            printf("    frame %d,%d\n",
                (int)frame_parameter.ux_host_class_video_parameter_frame_width,
                (int)frame_parameter.ux_host_class_video_parameter_frame_height);
        }
#endif

        /* Save the current frame index.  */
        video -> ux_host_class_video_current_frame = frame_index;

        uvc_parameter_interval_list(video);
    }

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("    --\n");
    }
#endif

    return(status);
}


/* Show the device parameters */
VOID uvc_parameter_list(UX_HOST_CLASS_VIDEO *video)
{
    ULONG format_index;
    UX_HOST_CLASS_VIDEO_PARAMETER_FORMAT_DATA format_parameter;

    UINT status = UX_SUCCESS;
    int i;

    /* format types */
#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("\n--- format types\n");
    }
#endif

    for (format_index = 1; format_index <= video -> ux_host_class_video_number_formats; format_index++)
    {
        /* Get format data for current format index.  */
        format_parameter.ux_host_class_video_parameter_format_requested = format_index;
        status = _ux_host_class_video_format_data_get(video, &format_parameter);
        if (status == UX_SUCCESS)
        {
#ifdef SEMI_HOSTING
            if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
            {
                /* Show the format type  */
                char* type_name;

                type_name = "Unknow type name";
                for(i=0; (unsigned int)i<(sizeof(vs_type_name)/sizeof(vs_type_name[0])); i++)
                {
                    if(format_parameter.ux_host_class_video_parameter_format_subtype==(ULONG)vs_type_name[i].type)
                    {
                        type_name = vs_type_name[i].name;
                        break;
                    }
                }

                printf("format %s\n", type_name);
            }
#endif
            /* Save number of frames in the video instance.  */
            video -> ux_host_class_video_number_frames = format_parameter.ux_host_class_video_parameter_number_frame_descriptors;

            uvc_parameter_frame_list(video);
        }
    }

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("--\n");
    }
#endif
}

VOID uvc_process_function(UX_HOST_CLASS_VIDEO* video)
{
    /* This demo uses two buffers. One buffer is used by video device while the
       application consumes data in the other buffer. */ 
    UCHAR *buffer_ptr[MAX_NUM_BUFFERS];

    /* Index variable keeping track of the current buffer being used by the video device. */ 
    ULONG buffer_index; 

    /* Maximum buffer requirement reported by the video device. */ 
    ULONG max_buffer_size; 

    UINT status;
    ULONG actual_flags;
    UINT frame_count;

    UX_HOST_CLASS_VIDEO_PARAMETER_CHANNEL channel;

    /* List parameters */
    uvc_parameter_list(video);

    /* Set video parameters. This setting value is a dummy. 
       Depending on the application, set the necessary parameters. */
    status = ux_host_class_video_frame_parameters_set(video,
                UX_HOST_CLASS_VIDEO_VS_FORMAT_MJPEG,
                176, 144,
                333333);
#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("parameters set status = %d\n", status);
    }
#endif

    /* Set the user callback function of video class. */
    ux_host_class_video_transfer_callback_set(video, uvc_transfer_request_done_callback);

    /* Find out the maximum memory buffer size for the video configuration
       set above. */
    max_buffer_size = ux_host_class_video_max_payload_get(video);

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("max_buffer_size = %d\n", (int)max_buffer_size);
    }
#endif

    /* Clear semaphore to zero */
    while (1)
    {
        if(tx_semaphore_get(&g_data_received_semaphore, 0)==TX_NO_INSTANCE)
        {
            break;
        }
    }

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("Start video transfer.\n");
    }
#endif

    /* Start video transfer.  */
    status = ux_host_class_video_start(video);
    if(status!=UX_SUCCESS)
    {
        /* Setting these to zero is a hack since we're mixing old and new APIs (new API does this and is required for reads). */
        video -> ux_host_class_video_transfer_request_start_index = 0;
        video -> ux_host_class_video_transfer_request_end_index = 0;

        channel.ux_host_class_video_parameter_format_requested = video -> ux_host_class_video_current_format;
        channel.ux_host_class_video_parameter_frame_requested = video -> ux_host_class_video_current_frame;
        channel.ux_host_class_video_parameter_frame_interval_requested = video -> ux_host_class_video_current_frame_interval;
        channel.ux_host_class_video_parameter_channel_bandwidth_selection = 1024;

        status = ux_host_class_video_ioctl(video, UX_HOST_CLASS_VIDEO_IOCTL_CHANNEL_START, &channel);
    }
#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("start status = %d\n", status);
    }
#endif

    /* Allocate space for video buffer. */     
    for(buffer_index = 0; buffer_index < MAX_NUM_BUFFERS; buffer_index++)
    {
        buffer_ptr[buffer_index] = &video_buffer[max_buffer_size * buffer_index];

        /* Add buffer to the video device for video streaming data. */
        ux_host_class_video_transfer_buffer_add(video, buffer_ptr[buffer_index]);
    }


    buffer_index = 0;
    frame_count = 0;

    while (1)
    {
        /* Suspend here until a transfer callback is called. */
        status = tx_semaphore_get(&g_data_received_semaphore, 100); 
        if(status!=TX_SUCCESS)
        {
            /* Check camera status */
            status = tx_event_flags_get(&g_device_insert_eventflag, EVENTFLAG_USB_DEVICE_INSERTED, TX_OR, (ULONG *)&actual_flags, 0);
            if(status==TX_SUCCESS)
            {
                /* Stop video transfer.  */
                ux_host_class_video_stop(video);
            }
            break;
        }

        /* Received data. The callback function needs to obtain the actual
           number of bytes received, so the application routine can read the
           correct amount of data from the buffer. */ 

        /* Application can now consume video data while the video device stores 
           the data into the other buffer. */ 

        /* Add the buffer back for video transfer. */
        ux_host_class_video_transfer_buffer_add(video, buffer_ptr[buffer_index]); 

        /* Increment the buffer_index, and wrap to zero if it exceeds the 
           maximum number of buffers. */
        buffer_index = (buffer_index + 1);
        if(buffer_index >= MAX_NUM_BUFFERS)
        {
            buffer_index = 0; 
        }

        frame_count++;
    }

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("Stop video transfer. frame_count = %d\n\n", frame_count);
    }
#endif
}

/* Camera Thread entry function */
void camera_thread_entry(void)
{
    ULONG actual_flags;

#ifdef SEMI_HOSTING
#ifdef __GNUC__
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        initialise_monitor_handles(); /* function to enable printf() in debug console*/
    }
#endif
#endif

    while(1)
    {
        /* Suspend here until a USBX Host Class Instance gets ready. */
        tx_event_flags_get(&g_device_insert_eventflag, EVENTFLAG_USB_DEVICE_INSERTED, TX_OR, (ULONG *)&actual_flags, TX_WAIT_FOREVER);

#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf("Connected webcam\n");
        }
#endif

        /* This delay is required for now to get valid ISO IN UX_ENDPOINT instance. */
        tx_thread_sleep(100);

        if(video_host_class!=NULL)
        {
            uvc_process_function(video_host_class);
        }
    }
}

