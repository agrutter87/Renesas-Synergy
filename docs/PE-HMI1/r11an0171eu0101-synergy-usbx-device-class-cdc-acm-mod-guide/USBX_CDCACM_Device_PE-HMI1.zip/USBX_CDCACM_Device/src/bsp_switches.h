/* generated bsp_swicthes header file - do not edit */

#include "r_ioport.h"


#define PUSH_BUTTON_START    (0)
#define PUSH_BUTTON_COUNT    (0)
#define MULTI_COLOR			 (1)

/* Array to point to the IO-pins */
ioport_port_pin_t p_switches[PUSH_BUTTON_COUNT];
