/* generated bsp_swicthes header file - do not edit */

#include "r_ioport.h"

#define PUSH_BUTTON_S1       IOPORT_PORT_03_PIN_05
#define PUSH_BUTTON_S2       IOPORT_PORT_03_PIN_04
#define PUSH_BUTTON_S3       IOPORT_PORT_02_PIN_02

#define PUSH_BUTTON_START    (1)
#define PUSH_BUTTON_END      (3)
#define PUSH_BUTTON_COUNT    ((PUSH_BUTTON_END) - (PUSH_BUTTON_START)+1)
#define MULTI_COLOR			 (1)

/* Array to point to the IO-pins */
ioport_port_pin_t p_switches[PUSH_BUTTON_COUNT] = {PUSH_BUTTON_S1,PUSH_BUTTON_S2,PUSH_BUTTON_S3};
