/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/*
 * This example
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "new_thread0.h"

#define SEMI_HOSTING

#ifdef SEMI_HOSTING
#ifdef __GNUC__                 /* GCC Compiler */
extern void initialise_monitor_handles(void);
#endif
#endif

void error_trap(char *msg, ULONG status);
void error_trap(char *msg, ULONG status)
{
#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("%s failed. error = %d\n",msg, (int)status);
    }
#endif
    while(1)
    {

    }
}


#define UX_BUFFER_SIZE (128)
#define CDCACM_FLAG ((ULONG)0x0001)

/* CDC-ACM reception data buffer. */
static unsigned char buffer[UX_BUFFER_SIZE];


/* A pointer to store CDC-ACM device instance. */
static UX_SLAVE_CLASS_CDC_ACM* g_cdc = UX_NULL;

/* USBX CDC-ACM Instance Activate User Callback Function */
VOID ux_cdc_device0_instance_activate(VOID * cdc_instance)
{
    /* Save the CDC instance.  */
    g_cdc = (UX_SLAVE_CLASS_CDC_ACM *)cdc_instance;
    tx_event_flags_set(&g_cdcacm_activate_event_flags0, CDCACM_FLAG, TX_OR);
}

/* USBX CDC-ACM Instance Deactivate User Callback Function */
VOID ux_cdc_device0_instance_deactivate(VOID * cdc_instance)
{
    SSP_PARAMETER_NOT_USED(cdc_instance);

    tx_event_flags_set(&g_cdcacm_activate_event_flags0, ~CDCACM_FLAG, TX_AND);
    g_cdc = UX_NULL;
}

/* The body of the only thread in this example */
void new_thread0_entry(void)
{
    ULONG status;
    ULONG actual_flags;
    ULONG actual_length;

#ifdef SEMI_HOSTING
#ifdef __GNUC__
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        initialise_monitor_handles();
    }
#endif
#endif

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("USBX_CDCACM_Device running\n\n");
    }
#endif

    /* Check if a CDC device is connected */
    status = tx_event_flags_get(&g_cdcacm_activate_event_flags0, CDCACM_FLAG,  TX_OR, &actual_flags,  TX_NO_WAIT);
    if(status && (status != TX_NO_EVENTS))
    {
        error_trap("tx_event_flags_get 1", status);
    }

    /* Wait for a CDC device to be connected */
    while (!(actual_flags & CDCACM_FLAG))
    {
#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf("Waiting for a CDC device to be connected...\n");
        }
#endif

        /* 1. Wait for the CDCACM event flag */
        status = tx_event_flags_get(&g_cdcacm_activate_event_flags0, CDCACM_FLAG,  TX_OR, &actual_flags,  TX_WAIT_FOREVER);
        if(status)
        {
            error_trap("tx_event_flags_get 2", status);
        }

#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf("Event detected\n");
        }
#endif
    }

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf("CDC device connected\n");
    }
#endif

    /* Perform an echo function by reading characters from the CDC device and writing them back */
    while(1)
    {

        /* 2. Read from the CDC device. This is a blocking call */
        status = ux_device_class_cdc_acm_read(g_cdc, buffer, UX_BUFFER_SIZE, &actual_length);
        if (status)
        {
            error_trap("ux_device_class_cdc_acm_read", status);
        }

#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf("%d characters read\n", (int)actual_length);
        }
#endif

        /* 3. Write back to the CDC device.  */
        status = ux_device_class_cdc_acm_write(g_cdc, buffer, actual_length, &actual_length);
        if(status)
        {
            error_trap("ux_device_class_cdc_acm_write", status);
        }

#ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf("%d characters written\n", (int)actual_length);
        }
#endif

    }
}

