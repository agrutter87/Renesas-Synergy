#ifndef HTTP_SERVER_H_
#define HTTP_SERVER_H_



typedef struct
{
    unsigned int hour;
    unsigned int minute;
    unsigned int seconds;
    char ampm[3];
}htime_t;

typedef struct
{
    unsigned int day;
    unsigned int month;
    unsigned int year;
}hdate_t;

typedef struct
{
    unsigned int push_button_count;
    float temperature;
    htime_t time;
    hdate_t date;

    unsigned long blink_ticks;
    unsigned int blink;
    unsigned int backlit_value;
    unsigned int vc;
} hconents_value_t;

#define ASSOCIATION_DONE_EVENT        (0x1)
#define EVENT_MASK                    ASSOCIATION_DONE_EVENT

#endif /* HTTP_SERVER_H_ */
