/* This is a small demo of the high-performance NetX TCP/IP stack.  */
/* Start of the WiFi driver initialization processing. */

#include "system_thread.h"
#if AUDIO
#include "audio.h"
#endif
//#include  "fx_api.h"
#include  "http_server.h"
#include  "tx_api.h"
#include  "nx_api.h"
#include  "nx_http.h"
#include  "system_time.h"
#include  "blink_thread.h"
#include  "brightness.h"

UINT authentication_check(struct NX_HTTP_SERVER_STRUCT *server_ptr, UINT request_type, CHAR *resource, CHAR **name, CHAR **password, CHAR **realm);
UINT request_notify(NX_HTTP_SERVER *server_ptr, UINT request_type, CHAR *resource, NX_PACKET *packet_ptr);

extern void brightup(void);
extern void brightdown(void);
void brightness_up(uint8_t * p_brightness);

/*******************************************************************************************************************//**
 * @brief  Decreases screen brightness within allowable configurable range and updates state.
 *
 * @param[in,out]  p_brightness  Current brightness.
***********************************************************************************************************************/
void brightness_down(uint8_t * p_brightness);


static char buff[2048];
static char buff_send[2048];


/* here is my local HTML contents */
char my_get_contents_updated[] =
"<html>"
"<head><title>NetX HTTP Server</title></head>"
"<body bgcolor=\"#0080FF\" >"
"<font color=\"Gold\">"

"<br>\r\n"
"<br>\r\n"
"<br>\r\n"
#if 1
  "<H1 ALIGN=\"center\">"
     "<meta http-equiv=\"refresh\" content=\"2\">"
  "  Renesas Synergy "
  "</H1>\r\n"
#endif
  "<H1 ALIGN=\"center\">"
  "  Wi-Fi Framework Application Demo "
  "</H1>\r\n"

  "<table ALIGN=\"center\" width=\"100\">\r\n"

    "<tr>"
      "<H1 ALIGN=\"center\"> "
      "<td> Temperature </td>"
      "<td><input type=text value=\"%02d F\" readonly=\"readonly\" style=\"text-align:center\"></td>\r\n"
      "</H1>\r\n"
    "</tr>"

    "<tr>"
      "<H1 ALIGN=\"center\"> "
      "<td> Time </td>"
      "<td><input type=text value=\"%02d:%02d %s\" readonly=\"readonly\" style=\"text-align:center\"></td>\r\n"
      "</H1>\r\n"
    "</tr>"

    "<tr>"
      "</H1>\r\n"
      "<td> Date </td>"
      "<td><input type=text value=\"%02d/%02d/%04d\" readonly=\"readonly\" style=\"text-align:center\"></td>\r\n"
      "</H1>\r\n"
    "</tr>"


  "</table>\r\n"

  "<br>\r\n"

    "<font color=\"Orange\">"

  "<form ALIGN=\"center\" method=\"POST\" action=\"index.html\">\r\n"
    "<H2 ALIGN=\"center\"> "
    "' LED  CONTROL '"
    "<br><input type=submit name=\"blink\" value=\"ON\"> \t  <input type=submit name=\"blink\" value=\"OFF\"> <input type=submit name=\"blink\" value=\"BLINK\"> \r\n \r\n"
    "</H2>\r\n"
 "</form>\r\n\r\n"
#if !defined(BSP_BOARD_S7G2_SK)
 "<form ALIGN=\"center\" method=\"POST\" action=\"index.html\">"
    "<H2 ALIGN=\"center\"> "
    "' BRIGHTNESS  CONTROL '"
    "<br><input type=submit name=\"bc\" value=\"UP\"> \t \t  <input type=submit name=\"bc\" value=\"DN\">"
    "</H2>"
  "</form>\r\n"
#endif

 "<H1 ALIGN=\"center\">"
 "  Powered By Synergy MCU S7G2 "
 "</H1>\r\n"

"<br><br>\r\n"
"</font>"
"</body>"
"</html>";

char my_post_contents[] = 
"<html>"
"<head><title>Post page(posted)</title></head>"
"<body>posted data [%s]</body>"
"</html>";

/**********/


/* contents Default values */

hconents_value_t http_conents_value =
{
    0,
	0,	//
	{
	14,
	15,
	45,
	"AM",
	},      // 14:05:45
	{
	28,
	01,
	2017,
	},      // Jun. 28 2016
	70,
	50,		// blink:	50 ticks
	50,		// ALS
	0
};





UINT authentication_check(struct NX_HTTP_SERVER_STRUCT *server_ptr, UINT request_type, CHAR *resource, CHAR **name, CHAR **password, CHAR **realm)
{
       SSP_PARAMETER_NOT_USED(resource);
       SSP_PARAMETER_NOT_USED(request_type);
       SSP_PARAMETER_NOT_USED(server_ptr);
   #if 0
     *name =  "Renesas";
     *password = "Reneas123";
     *realm =  "test.htm";
     return(NX_HTTP_BASIC_AUTHENTICATE);
   #else
     SSP_PARAMETER_NOT_USED(name);
     SSP_PARAMETER_NOT_USED(password);
     SSP_PARAMETER_NOT_USED(realm);
     return(NX_SUCCESS);
   #endif
}


UINT request_notify(NX_HTTP_SERVER *server_ptr, UINT request_type, CHAR *resource, NX_PACKET *packet_ptr)
{
    UINT len;

	UINT actual_size;
	int temp_in_f;
#if 0
	UINT temp;
#endif


	if((strcmp(resource, "/index.html")==0) ||
		(strcmp(resource, "/")==0))
	{
		if(request_type == NX_HTTP_SERVER_GET_REQUEST)
		{
			temp_in_f = (int)(http_conents_value.temperature * 1.8) + 32;
			sprintf(buff_send, my_get_contents_updated,
					(temp_in_f),
					(http_conents_value.time.hour), (http_conents_value.time.minute),  (http_conents_value.time.ampm),		// Time
					(http_conents_value.date.month), (http_conents_value.date.day), (http_conents_value.date.year),	// Date
					(http_conents_value.push_button_count)
					);

			len = strlen(buff_send);
			sprintf(buff, "HTTP/1.0 200 \r\nContent-Length: %d\r\nContent-Type: text/html\r\n\r\n", len);

			nx_http_server_callback_data_send(server_ptr, buff, strlen(buff));
			nx_http_server_callback_data_send(server_ptr, buff_send, len);
		}
		else
		{
			len = nx_http_server_content_length_get(packet_ptr);
			nx_http_server_content_get(server_ptr, packet_ptr, 0, buff, sizeof(buff), &actual_size);
			buff[actual_size] = '\0';
#ifdef CHECK_POST
			sprintf(buff_send, my_post_contents, buff);

			len = strlen(buff_send);
			sprintf(buff, "HTTP/1.0 200 \r\nContent-Length: %d\r\nContent-Type: text/html\r\n\r\n", len);

			nx_http_server_callback_data_send(server_ptr, buff, strlen(buff));
			nx_http_server_callback_data_send(server_ptr, buff_send, len);
#else
			if(strcmp(buff,"blink=ON")==0)
			{
				http_conents_value.blink = 1;	// Set to 'Yes'

				/* The event flag is set for 'Yes'. */
				tx_event_flags_set(&blink_flag, (ULONG)~(0xFF), TX_AND);
				tx_event_flags_set(&blink_flag, (ULONG)0x2, TX_OR);
			}
			else if(strcmp(buff,"blink=OFF")==0)
			{
				http_conents_value.blink = 1;	// Set to 'No'

				/* The event flag is cleared for 'No'. */
				tx_event_flags_set(&blink_flag, (ULONG)~(0xFF), TX_AND);
				tx_event_flags_set(&blink_flag, (ULONG)0x4, TX_OR);
			}
			else if(strcmp(buff,"blink=BLINK")==0)
			{
				http_conents_value.blink = 1;	// Set to 'No'
				/* The event flag is cleared for 'No'. */
				tx_event_flags_set(&blink_flag, (ULONG)~(0xFF), TX_AND);
				tx_event_flags_set(&blink_flag, (ULONG)0x1, TX_OR);
			}
#if !defined(BSP_BOARD_S7G2_SK)
            else if(strcmp(buff,"bc=UP")==0)
            {
                 brightup();
            }
            else if(strcmp(buff,"bc=DN")==0)
            {
                 brightdown();
            }
#endif
			else
			{
				sprintf(buff_send, my_post_contents, buff);

				len = strlen(buff_send);
				sprintf(buff, "HTTP/1.0 200 \r\nContent-Length: %d\r\nContent-Type: text/html\r\n\r\n", len);

				nx_http_server_callback_data_send(server_ptr, buff, strlen(buff));
				nx_http_server_callback_data_send(server_ptr, buff_send, len);

				return(NX_HTTP_FAILED);
			}

			temp_in_f = (int)(http_conents_value.temperature * 1.8) + 32 ;
			sprintf(buff_send, my_get_contents_updated,
					(temp_in_f),			// Temperature
					(http_conents_value.time.hour), (http_conents_value.time.minute), (http_conents_value.time.ampm), // Time
					(http_conents_value.date.month), (http_conents_value.date.day),(http_conents_value.date.year),	// Date
					(http_conents_value.push_button_count)
				);

			len = strlen(buff_send);
			sprintf(buff, "HTTP/1.0 200 \r\nContent-Length: %d\r\nContent-Type: text/html\r\n\r\n", len);

			nx_http_server_callback_data_send(server_ptr, buff, strlen(buff));
			nx_http_server_callback_data_send(server_ptr, buff_send, len);
#endif /** CHECK_POST */
		}

		return(NX_HTTP_CALLBACK_COMPLETED);
	}

	return(NX_HTTP_FAILED);
}


