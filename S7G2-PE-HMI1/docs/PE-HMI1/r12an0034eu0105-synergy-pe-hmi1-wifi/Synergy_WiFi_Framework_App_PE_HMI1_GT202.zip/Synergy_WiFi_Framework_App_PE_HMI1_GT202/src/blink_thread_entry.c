#include "blink_thread.h"
#include "hal_data.h"
#include "r_ioport.h"
#include "http_server.h"
#include "system_cfg.h"

#define  BLINK  0x01
#define  ON     0x02
#define  OFF    0x04
#define  MASK   0x07

// External Declarations
extern hconents_value_t http_conents_value;

static bsp_leds_t leds;


void blink_thread_entry()
{
 UINT    status = 0xFFFF;
 ULONG   actual_flags;
 volatile ioport_level_t level;

 /* Define the units to be used with the threadx sleep function */
 const uint32_t threadx_tick_rate_Hz = 100;
 /* Set the blink frequency (must be <= threadx_tick_rate_Hz */
 const uint32_t freq_in_hz = 2;
 /* Calculate the delay in terms of the threadx tick rate */
 const uint32_t delay = threadx_tick_rate_Hz/freq_in_hz;

    /* Get LED information for this board */
    R_BSP_LedsGet(&leds);


    /* If this board has no LEDs then trap here */
    if (!leds.led_count)
    {
        APP_ERR_TRAP(status);   // There are no LEDs on this board
    }

    level = IOPORT_LEVEL_HIGH;


    while(true)
    {

        status =  tx_event_flags_get(&blink_flag, MASK, TX_OR,
                                     &actual_flags, TX_WAIT_FOREVER);

        if(status!=TX_SUCCESS)
        {
            APP_ERR_TRAP(status);   // Even get failed
        }
        actual_flags = actual_flags & MASK;

        if(actual_flags == ON){
            /* Turn ON the LED */
            level = IOPORT_LEVEL_HIGH;
            for(uint32_t i = 0; i < leds.led_count; i++)
            {
                g_ioport.p_api->pinWrite(leds.p_leds[i], level);
            }
        }else if (actual_flags == OFF){
            /* Turn OFF the LED */
            level = IOPORT_LEVEL_LOW;
            for(uint32_t i = 0; i < leds.led_count; i++)
            {
                g_ioport.p_api->pinWrite(leds.p_leds[i], level);
            }
        }else if (actual_flags == BLINK){
            /* Toggle the LED */
            level = (ioport_level_t)!level;
            for(uint32_t i = 0; i < leds.led_count; i++)
            {
                g_ioport.p_api->pinWrite(leds.p_leds[i], level);
            }
        }

        /* Wait a period of time */
        tx_thread_sleep(delay);
    }
}
