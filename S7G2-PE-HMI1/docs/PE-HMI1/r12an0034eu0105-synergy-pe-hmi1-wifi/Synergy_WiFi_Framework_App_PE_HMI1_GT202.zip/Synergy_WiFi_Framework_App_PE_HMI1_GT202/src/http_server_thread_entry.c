#include "http_server_thread.h"
#include "nx_http_server.h"
#include "nx_http.h"
#include "nx_api.h"
#include "system_cfg.h"

/* HTTP Thread entry function */
void http_server_thread_entry(void)
{
 UINT    status = 0;
 ULONG   ip0_ip_address = 0;
 ULONG   ip0_mask = 0;

    while (status != NX_IP_ADDRESS_RESOLVED) {
        /* Wait for IP address to be resolved through DHCP. */
        nx_ip_status_check(&g_ip0, NX_IP_ADDRESS_RESOLVED, (ULONG *) &status, 10);
    }

    status =  nx_ip_interface_address_get(&g_ip0, 0, &ip0_ip_address, &ip0_mask);

      /* Check for errors.  */
    if (status)
    {
        APP_ERR_TRAP(status);   // IP address Get failure;
    }
    status =  nx_http_server_start(&g_http_server0);

      /* Check for errors.  */
    if (status)
    {
        APP_ERR_TRAP(status);   // HTTP Start API returned error;
    }

    /* From Here onwards the Internal HTTP Server thread will take care of handling the HTTP messages along with get_notify function */
    while (true)
    {
        tx_thread_sleep (10);
    }
}
