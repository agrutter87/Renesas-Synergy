#include "wifi_app_thread.h"
#include "sf_message_payloads.h"
#include "system_cfg.h"

#define CONFIGURED 1
#define PROVISIONED 1
#define NOT_PROVISIONED 0
#define MESSAGE_NOT_SENT 0
#define MESSAGE_SENT 1

#if 1
#define MY_SSID_FOR_AP "Cisco36183"    /* Change this to your Wi-Fi AP/Router’s SSID */
#define MY_PASSWORD_FOR_AP "12345678"  /* Change this to your Wi-Fi AP/Router’s Password */
#endif
#if 0
#define MY_SSID_FOR_AP "Tvilola_2GEXT"    /* Change this to your Wi-Fi AP/Router’s SSID */
#define MY_PASSWORD_FOR_AP "@5106512878"  /* Change this to your Wi-Fi AP/Router’s Password */
#endif

/***********************************************************************************************************************
 * Exported global functions (to be accessed by other files)
 **********************************************************************************************************************/
extern const sf_message_post_cfg_t g_post_cfg;
extern const sf_message_acquire_cfg_t g_acquire_cfg;


void client_mode_start (void);
static uint8_t  ip_configured = 0;
static uint8_t  wifi_provisioned = 0;

static ULONG   ip0_ip_address = 0;
ULONG   ip0_mask = 0;
ULONG   error_counter;
char    str[64];


void client_mode_start (void)
{
 sf_wifi_provisioning_t g_provision_info;
 ssp_err_t result = SSP_ERR_IN_USE;
 UINT status;
 ULONG     ip_status;


     do
     {
     /* Wait for the link to come up.  */
         status =  nx_ip_status_check(&g_ip0, NX_IP_LINK_ENABLED, &ip_status, 300);
     } while (status);

    /** Set other provisioning configuration */
    g_provision_info.mode = SF_WIFI_INTERFACE_MODE_CLIENT;
    g_provision_info.security = SF_WIFI_SECURITY_TYPE_WPA2;
    g_provision_info.encryption = SF_WIFI_ENCRYPTION_TYPE_AUTO;


    strcpy((char *)&g_provision_info.ssid,(const char *)MY_SSID_FOR_AP);
    strcpy((char *)&g_provision_info.key,(const char *)MY_PASSWORD_FOR_AP);


    do {
        result = g_sf_wifi0.p_api->provisioningSet(g_sf_wifi0.p_ctrl, &g_provision_info);
    } while (result != SSP_SUCCESS);

    if(status == SSP_SUCCESS)
    {
        wifi_provisioned = PROVISIONED;
    }
    else
    {
        APP_ERR_TRAP(status);
    }
   /* Start the DHCP Client application */
   status = nx_dhcp_start (&g_dhcp_client0);

   if (status != NX_SUCCESS)
   {
       APP_ERR_TRAP(status);
   }

   while (status != NX_IP_ADDRESS_RESOLVED) {
      /* Wait for IP address to be resolved through DHCP. */
       nx_ip_status_check(&g_ip0, NX_IP_ADDRESS_RESOLVED, (ULONG *) &status, 10);
   }

   status =  nx_ip_interface_address_get(&g_ip0,0,&ip0_ip_address,&ip0_mask);

   if(status == NX_SUCCESS)
   {
       ip_configured = 1;
   }
   else
   {
       APP_ERR_TRAP(status);
   }
   sprintf(str, "IP ADDRESS: %d.%d.%d.%d \n\r", (int)(ip0_ip_address>>24), (int)(ip0_ip_address>>16)&0xFF, (int)(ip0_ip_address>>8)&0xFF, (int)(ip0_ip_address)&0xFF );
}

/* WiFi App Thread entry function */
void wifi_app_thread_entry(void)
{
 ULONG     ip_status;
 UINT      status;
 static uint8_t  wifi_provisioned_msg_sent = 0;

    /** Wait for init to finish. */
    status = nx_ip_interface_status_check(&g_ip0, 0, NX_IP_LINK_ENABLED, &ip_status, NX_WAIT_FOREVER);

    if (status)
    {
          APP_ERR_TRAP(status);   // IP Link enable  failure;
    }

    client_mode_start();

    while(1)
    {
        /** Send event. */
         sf_message_header_t * p_message  = NULL;
         sf_message_payload_t * p_payload = NULL;
         ssp_err_t err;

         if((NOT_PROVISIONED != wifi_provisioned) && (MESSAGE_SENT != wifi_provisioned_msg_sent))
         {
             /** Get buffer from messaging framework. */
             err = g_sf_message.p_api->bufferAcquire(g_sf_message.p_ctrl, (sf_message_header_t **) &p_message, &g_acquire_cfg, TX_NO_WAIT);
             if (SSP_SUCCESS != err)
             {
                 APP_ERR_TRAP(err);
                /** Post error message. */
             }
             else
             {

                 /** Create message in buffer. */
                 p_message->event_b.class_code = SF_MESSAGE_EVENT_CLASS_WIFI;
                 p_message->event_b.code  = SF_MESSAGE_EVENT_UPDATE_WIFI_ICON;
                 p_payload = (sf_message_payload_t*)(p_message+1);
                 p_payload->wifi_payload.wifi_mode = 1;

                 /** Post message. */
                 sf_message_post_err_t post_err;
                 err = g_sf_message.p_api->post(g_sf_message.p_ctrl, (sf_message_header_t *) p_message, &g_post_cfg, &post_err, TX_NO_WAIT);
                 if (SSP_SUCCESS != err)
                 {
                    /** Message is processed, so release buffer. */
                     APP_ERR_TRAP(err);
                    /** TODO_THERMO: Post error message. */
                 }
                 wifi_provisioned_msg_sent = MESSAGE_SENT;
             }
          }
          if (CONFIGURED == ip_configured)
          {
                     /** Get buffer from messaging framework. */
                     err = g_sf_message.p_api->bufferAcquire(g_sf_message.p_ctrl, (sf_message_header_t **) &p_message, &g_acquire_cfg, TX_NO_WAIT);
                     if (SSP_SUCCESS != err)
                     {
                         APP_ERR_TRAP(err);
                         /** Post error message. */
                     }
                     else
                     {

                         /** Create message in buffer. */
                         p_message->event_b.class_code = SF_MESSAGE_EVENT_CLASS_WIFI;
                         p_message->event_b.code  = SF_MESSAGE_EVENT_UPDATE_IP_ADDRESS;
                         p_payload = (sf_message_payload_t*)(p_message+1);
                         p_payload->wifi_payload.ip[0] = (uint8_t)((ip0_ip_address>>24) & 0xFF);
                         p_payload->wifi_payload.ip[1] = (uint8_t)((ip0_ip_address>>16) & 0xFF);
                         p_payload->wifi_payload.ip[2] = (uint8_t)((ip0_ip_address>>8) & 0xFF);
                         p_payload->wifi_payload.ip[3] = (uint8_t)((ip0_ip_address) & 0xFF);

                         /** Post message. */
                         sf_message_post_err_t post_err;
                         err = g_sf_message.p_api->post(g_sf_message.p_ctrl, (sf_message_header_t *) p_message, &g_post_cfg, &post_err, TX_NO_WAIT);
                         if (SSP_SUCCESS != err)
                         {
                             /** Message is processed, so release buffer. */
                             APP_ERR_TRAP(err);
                             /** TODO_THERMO: Post error message. */
                         }
                     }

        }
        tx_thread_sleep(200);
    }
}

