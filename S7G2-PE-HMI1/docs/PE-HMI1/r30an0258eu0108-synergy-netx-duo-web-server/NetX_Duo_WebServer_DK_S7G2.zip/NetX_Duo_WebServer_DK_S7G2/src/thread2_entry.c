/***********************************************************************************************************************
 * Includes
 ***********************************************************************************************************************/
#include <thread2.h>

/***********************************************************************************************************************
 * Macro definitions
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 * function prototypes
 ***********************************************************************************************************************/
void thread2_entry(void);

/***********************************************************************************************************************
 * global variables
 ***********************************************************************************************************************/
ULONG thread_2_counter;
ULONG thread_2_messages_received;
extern TX_QUEUE g_queue_0;

/* thread2 entry function */
void thread2_entry(void)
{
ULONG   received_message;
UINT    status;

    /* This thread retrieves messages placed on the queue by thread 1.  */
    while(1)
    {

        /* Increment the thread counter.  */
        thread_2_counter++;

        /* Retrieve a message from the queue.  */
        status = tx_queue_receive(&g_queue_0, &received_message, TX_WAIT_FOREVER);

        /* Check completion status and make sure the message is what we
           expected.  */
        if ((status != TX_SUCCESS) || (received_message != thread_2_messages_received))
            break;

        /* Otherwise, all is okay.  Increment the received message count.  */
        thread_2_messages_received++;
    }
}
