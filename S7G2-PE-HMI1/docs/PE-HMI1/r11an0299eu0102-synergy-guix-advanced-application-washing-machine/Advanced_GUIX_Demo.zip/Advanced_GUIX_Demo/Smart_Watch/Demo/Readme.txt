
Connect the J-LINK to the PE-HMI1 board and other end to the PC. 

Power the PE-HMI1 Board and run ("Double Click") the "Smart_Watch_Demo.bat" file (from Installer Directory) which
will start programming the board via the J-LINK connector, connected to the PC. 

After the successful programming, power cycle the board and you will start seeing the Demo running.

