
#include "gx_api.h"

#define USER_TYPE_RADIAL_SLIDER GX_FIRST_USER_WINDOW_TYPE
#define USER_EVENT_ANIMATION_COMPLETE GX_FIRST_APP_EVENT
#define USER_EVENT_ANIMATION_START    GX_FIRST_APP_EVENT + 1
#define USER_EVENT_SLIDER_VALUE       GX_FIRST_APP_EVENT + 2
#define RADIAL_SLIDER_ANIMATION_TIMER 2

#define STATUS_NONE           1
#define STATUS_TRACKING       3
#define STATUS_LANDING        4

#define TRACKING_DIRECTION_ANTICLOCKWISE  1
#define TRACKING_DIRECTION_CLOCKWISE      2

/* Define radial slider information structure. */
typedef struct RADIAL_SLIDER_INFO_STRUCT{
    GX_RESOURCE_ID needle_pixelmap;
    GX_VALUE       xcenter;
    GX_VALUE       ycenter;
    GX_VALUE       radius;                 /* radius of circular track.  */
    GX_VALUE       track_width;
    GX_VALUE       min_angle;
    GX_VALUE       max_angle;
    GX_VALUE       list_count;
    GX_VALUE      *angle_list;
}RADIAL_SLIDER_INFO;

/* Define radial slider structure. */
typedef struct RADIAL_SLIDER_STRUCT{
    GX_WIDGET_MEMBERS_DECLARE
    USHORT             status;
    GX_VALUE           current_val;             /* current slider position.  */
    GX_VALUE           target_val;
    GX_POINT           pen_down_point;
    RADIAL_SLIDER_INFO info;
    VOID             (*animation_update_callback)(INT remain_steps);
}RADIAL_SLIDER;

UINT radial_slider_create(RADIAL_SLIDER *slider, GX_CONST GX_CHAR *name, GX_WIDGET *parent,
    RADIAL_SLIDER_INFO *info, ULONG style, USHORT id, GX_RECTANGLE *size);
UINT radial_slider_animation_start(RADIAL_SLIDER *slider, GX_VALUE target_value);
UINT radial_slider_value_set(RADIAL_SLIDER *slider, GX_VALUE new_value);
UINT radial_slider_animation_update_callback_set(RADIAL_SLIDER *slider, VOID(*animation_update_callback)(INT remain_steps));
UINT radial_slider_needle_pixelmap_set(RADIAL_SLIDER *slider, GX_RESOURCE_ID needle_pixelmap);