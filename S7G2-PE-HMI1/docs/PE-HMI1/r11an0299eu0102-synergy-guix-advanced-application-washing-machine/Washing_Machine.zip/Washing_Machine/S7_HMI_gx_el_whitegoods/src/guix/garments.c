
#include "demo_guix_washing_machine.h"

/* Define variables. */

/* Define angles of each garments mode. */
GX_VALUE garments_mode_angles[] = { -63, -34, -10, 13, 38, 67, 112, 142, 168, 191, 214, 242 };

/* Define icon angles of each garments mode, the icon is in the center of the radial slider, 
which rotate together with the slider needle. */
GX_VALUE garments_mode_icon_angles[] = { 300, 270, 240, 210, 190, 160, 110, 70, 50, 30, 0, -20 };

/* Define prompt widget that each mode correspond to. */
GX_WIDGET *garments_mode_label_widgets[] = {
    (GX_WIDGET *)&garments_window.garments_window_mode_workout_clothes,
    (GX_WIDGET *)&garments_window.garments_window_mode_hand_wash,
    (GX_WIDGET *)&garments_window.garments_window_mode_wool,
    (GX_WIDGET *)&garments_window.garments_window_mode_silk,
    (GX_WIDGET *)&garments_window.garments_window_mode_bedding,
    (GX_WIDGET *)&garments_window.garments_window_mode_baby_care,
    (GX_WIDGET *)&garments_window.garments_window_mode_cotton,
    (GX_WIDGET *)&garments_window.garments_window_mode_synthetics,
    (GX_WIDGET *)&garments_window.garments_window_mode_denim,
    (GX_WIDGET *)&garments_window.garments_window_mode_linen,
    (GX_WIDGET *)&garments_window.garments_window_mode_dark_colors,
    (GX_WIDGET *)&garments_window.garments_window_mode_light_colors
};

/* Define current selection mode index. */
static INT selected_index = 11;
static INT target_index = 11;

/* Define current icon angle, the angle is larged by 256 for
the precision needs. */
static INT current_garments_icon_angle = 0;

RADIAL_SLIDER garments_mode_radial_slider;
RADIAL_SLIDER_INFO garments_mode_radial_slider_info;

extern INT blend_alpha;
GX_PIXELMAP rotated_map;

/* Define prototypes. */
VOID garments_page_init();
VOID garments_mode_radial_slider_create();
VOID garments_mode_label_widgets_update(int old_selected_index);
VOID garments_mode_icon_angle_update(int remain_step);
void rotated_map_create();

/******************************************************************************************/
/* Override default event processing of "garments on" window to handle signals from my    */
/* child widgets.                                                                         */
/******************************************************************************************/
UINT garments_window_event_process(GX_WINDOW *window, GX_EVENT *event_ptr)
{
    GX_WIDGET *widget;
    int index;
    int old_selected_index;

    switch (event_ptr->gx_event_type)
    {
    case GX_EVENT_SHOW:
        gx_window_event_process(window, event_ptr);
        memset(&rotated_map, 0, sizeof(GX_PIXELMAP));
        rotated_map_create();
        break;

    case GX_SIGNAL(ID_GARMENTS_MODE_WORKOUT_CLOTHES, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_HAND_WASH, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_WOOL, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_SILK, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_BEDDING, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_BABY_CARE, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_COTTON, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_SYNTHETICS, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_DENIM, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_LINEN, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_DARK_COLORS, GX_EVENT_CLICKED):
    case GX_SIGNAL(ID_GARMENTS_MODE_LIGHT_COLORS, GX_EVENT_CLICKED):
        gx_widget_find((GX_WIDGET *)window, (USHORT)(event_ptr->gx_event_type >> 8), GX_SEARCH_DEPTH_INFINITE, &widget);
        if (widget)
        {
            for (index = 0; index < (INT)(sizeof(garments_mode_angles) / sizeof(GX_VALUE)); index++)
            {
                if (garments_mode_label_widgets[index] == widget)
                {
                    /* Start animation to move slider needle from current mode to target mode. */
                    radial_slider_animation_start(&garments_mode_radial_slider, garments_mode_angles[index]);
                }
            }
        }
        break;

    case USER_EVENT_ANIMATION_START:
        for (index = 0; index < garments_mode_radial_slider_info.list_count; index++)
        {
            if (garments_mode_angles[index] == event_ptr->gx_event_payload.gx_event_intdata[0])
            {
                target_index = index;
                break;
            }
        }
        break;

    case USER_EVENT_ANIMATION_COMPLETE:
        for (index = 0; index < garments_mode_radial_slider_info.list_count; index++)
        {
            if (garments_mode_angles[index] == event_ptr->gx_event_payload.gx_event_intdata[0])
            {
                old_selected_index = selected_index;
                selected_index = index;

                /* Update selection mode label. */
                garments_mode_label_widgets_update(old_selected_index);
            }
        }
        break;

    default:
        return gx_window_event_process(window, event_ptr);
    }

    return 0;
}

/******************************************************************************************/
/* Update some values when "garments on" button is selected.                              */
/******************************************************************************************/
VOID garments_page_init()
{
    GX_VALUE old_selected_index;

    /* Change page name to "Garments". */
    gx_prompt_text_set(&main_screen.main_screen_page_name, "Garments");

    /* Change page name color to orange. */
    gx_prompt_text_color_set(&main_screen.main_screen_page_name, GX_COLOR_ID_ORANGE, GX_COLOR_ID_ORANGE);

    /* Record old selection mode index. */
    old_selected_index = (GX_VALUE)selected_index;

    /* Init selection index to mode 11. */
    selected_index = 11;
    target_index = 11;

    /* Init garments icon angle. */
    current_garments_icon_angle = garments_mode_icon_angles[selected_index] << 8;

    /* Set slider value to mode 11. */
    radial_slider_value_set(&garments_mode_radial_slider, garments_mode_angles[selected_index]);

    /* Update selection mode labels. */
    garments_mode_label_widgets_update(old_selected_index);

    /* Start animation to move slider needle from mode 11 to mode 6*/
    radial_slider_animation_start(&garments_mode_radial_slider, garments_mode_angles[6]);

    widget_enable_disable((GX_WIDGET *)&garments_window, POWER_ON);
}

/******************************************************************************************/
/* Update some values when "garments on" button is de-selected.                           */
/******************************************************************************************/
void garments_page_power_off()
{
    widget_enable_disable((GX_WIDGET *)&garments_window, POWER_OFF);
}

/******************************************************************************************/
/* Update some values when "garments on" button is de-selected.                           */
/******************************************************************************************/
VOID garments_mode_radial_slider_create()
{
    GX_RECTANGLE size;

    size.gx_rectangle_left = garments_window.garments_window_wheel.gx_widget_size.gx_rectangle_left;
    size.gx_rectangle_top = garments_window.garments_window_wheel.gx_widget_size.gx_rectangle_top;
    size.gx_rectangle_right = (GX_VALUE)(size.gx_rectangle_left + RADIAL_SLIDER_WIDTH - 1);
    size.gx_rectangle_bottom = (GX_VALUE)(size.gx_rectangle_top + RADIAL_SLIDER_HEIGHT - 1);

    /* Define radial slider information. */
    memset(&garments_mode_radial_slider_info, 0, sizeof(RADIAL_SLIDER_INFO));
    garments_mode_radial_slider_info.min_angle = -63;
    garments_mode_radial_slider_info.max_angle = 242;
    garments_mode_radial_slider_info.xcenter = RADIAL_SLIDER_WIDTH >> 1;
    garments_mode_radial_slider_info.ycenter = RADIAL_SLIDER_HEIGHT >> 1;
    garments_mode_radial_slider_info.radius = RADIAL_SLIDER_RADIUS;
    garments_mode_radial_slider_info.track_width = RADIAL_SLIDER_TRACK_WIDTH;
    garments_mode_radial_slider_info.needle_pixelmap = GX_PIXELMAP_ID_WHEEL_DOT_ORANGE;
    garments_mode_radial_slider_info.angle_list = garments_mode_angles;
    garments_mode_radial_slider_info.list_count = sizeof(garments_mode_angles) / sizeof(GX_VALUE);

    /* Create a radial slider. */
    radial_slider_create(&garments_mode_radial_slider, "garments_radial_slider", (GX_WIDGET *)&garments_window,
        &garments_mode_radial_slider_info, GX_STYLE_TRANSPARENT | GX_STYLE_ENABLED, ID_RADIAL_SLIDER_WASHER_ON, &size);

    /* Set an callback function for the slider, this callback function is used to update the garments icon in 
    the center of the radia slider. */
    radial_slider_animation_update_callback_set(&garments_mode_radial_slider, garments_mode_icon_angle_update);
}

/******************************************************************************************/
/* Update text color of selected and de-selected mode labels.                             */
/******************************************************************************************/
VOID garments_mode_label_widgets_update(int old_selected_index)
{
    /* Change old selected mode label color to light gray. */
    gx_prompt_text_color_set((GX_PROMPT *)garments_mode_label_widgets[old_selected_index], GX_COLOR_ID_LIGHT_GRAY, GX_COLOR_ID_LIGHT_GRAY);

    /* Change new selected mode label color to orange. */
    gx_prompt_text_color_set((GX_PROMPT *)garments_mode_label_widgets[selected_index], GX_COLOR_ID_ORANGE, GX_COLOR_ID_ORANGE);
}

/******************************************************************************************/
/* Update rotating angle of the icon in the middle of the radial slider widget.           */
/******************************************************************************************/
VOID garments_mode_icon_angle_update(int current_val)
{
    INT icon_target_angle = garments_mode_icon_angles[target_index];
    INT icon_start_angle = garments_mode_icon_angles[selected_index];
    INT target_val = garments_mode_angles[target_index];
    INT start_val = garments_mode_angles[selected_index];

    if (target_index == selected_index)
    {
        return;
    }

    current_garments_icon_angle = (icon_target_angle - icon_start_angle) * (current_val - start_val)
                                  / (target_val - start_val);
    current_garments_icon_angle += icon_start_angle;

    rotated_map_create();

    /* Mark icon window as dirty. */
    gx_system_dirty_mark((GX_WIDGET *)&garments_window.garments_window_icon_window);
}

/******************************************************************************************/
/* Override default drawing of the icon in the center of the radial slider to draw the    */
/* icon with specified angle.                                                             */
/******************************************************************************************/
VOID icon_window_draw(GX_WINDOW *window)
{
    GX_PIXELMAP *map;
    int xpos;
    int ypos;

    if ((current_garments_icon_angle != 0) && rotated_map.gx_pixelmap_data)
    {
        map = &rotated_map;
    }
    else
    {
        /* Draw icon with the current icon angle. */
        gx_context_pixelmap_get(GX_PIXELMAP_ID_ICON_SOCK, &map);
    }

    xpos = (window->gx_widget_size.gx_rectangle_left + window->gx_widget_size.gx_rectangle_right) >> 1;
    xpos -= map->gx_pixelmap_width >> 1;

    ypos = (window->gx_widget_size.gx_rectangle_top + window->gx_widget_size.gx_rectangle_bottom) >> 1;
    ypos -= map->gx_pixelmap_height >> 1;

    gx_context_fill_color_set(GX_COLOR_ID_ORANGE);

    if (blend_alpha != GX_ALPHA_VALUE_OPAQUE)
    {
        gx_canvas_pixelmap_blend((GX_VALUE)xpos, (GX_VALUE)ypos, map, (GX_UBYTE)blend_alpha);
    }
    else
    {
        gx_canvas_pixelmap_draw((GX_VALUE)xpos, (GX_VALUE)ypos, map);
    }
}

/******************************************************************************************/
/* Rotate a pixelmap.                                                                     */
/******************************************************************************************/
void rotated_map_create()
{
    GX_PIXELMAP *map = GX_NULL;

    if (current_garments_icon_angle == 0)
    {
        return;
    }

    if (rotated_map.gx_pixelmap_data)
    {
        memory_free((void *)rotated_map.gx_pixelmap_data);
        rotated_map.gx_pixelmap_data = GX_NULL;
    }

    if (rotated_map.gx_pixelmap_aux_data)
    {
        memory_free((void *)rotated_map.gx_pixelmap_aux_data);
        rotated_map.gx_pixelmap_aux_data = GX_NULL;
    }

    gx_widget_pixelmap_get(&garments_window.garments_window_icon_window, GX_PIXELMAP_ID_ICON_SOCK, &map);

    if (map)
    {
        gx_utility_pixelmap_rotate(map, current_garments_icon_angle, &rotated_map, GX_NULL, GX_NULL);
    }
}
