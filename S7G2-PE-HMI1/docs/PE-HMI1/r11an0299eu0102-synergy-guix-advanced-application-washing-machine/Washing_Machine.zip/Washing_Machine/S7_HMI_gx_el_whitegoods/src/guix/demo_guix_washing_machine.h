/* This is a small demo of the high-performance GUIX graphics framework. */

#include <stdio.h>
#include "tx_api.h"
#include "gx_api.h"

#include "demo_guix_washing_machine_resources.h"
#include "demo_guix_washing_machine_specifications.h"
#include "radial_slider.h"

#define ID_RADIAL_SLIDER_WASHER_ON  0xff1
#define POWER_ON  1
#define POWER_OFF 2

#define RADIAL_SLIDER_WIDTH                 263
#define RADIAL_SLIDER_HEIGHT                262
#define RADIAL_SLIDER_TRACK_WIDTH           44
#define RADIAL_SLIDER_RADIUS                108
#define TEMPERATURE_WINDOW_LONG_LINE_WIDTH  60
#define TEMPERATURE_WINDOW_SHORT_LINE_WIDTH 18

VOID washer_on_page_init();
VOID washer_on_page_power_off();
VOID washer_mode_radial_slider_create();
VOID garments_page_init();
void garments_page_power_off();
VOID garments_mode_radial_slider_create();
VOID water_level_page_init();
VOID water_level_page_power_off();
VOID temperature_page_init();
VOID temperature_page_power_off();
VOID temperature_radial_slider_create();
VOID widget_enable_disable(GX_WIDGET *widget, INT status);

void memory_free(VOID *mem);

extern RADIAL_SLIDER garments_mode_radial_slider;
extern RADIAL_SLIDER washer_mode_radial_slider;

extern TEMPERATURE_WINDOW_CONTROL_BLOCK temperature_window;
extern WATER_LEVEL_WINDOW_CONTROL_BLOCK water_level_window;
extern GARMENTS_WINDOW_CONTROL_BLOCK garments_window;
extern MAIN_SCREEN_CONTROL_BLOCK main_screen;