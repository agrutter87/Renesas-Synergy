#include "video_thread.h"
#include "guix/demo_guix_washing_machine_specifications.h"

VOID guix_setup(GX_WINDOW_ROOT * root);

static GX_WINDOW_ROOT * p_window_root;

extern const void * p_resource_banner;

/* Video Thread entry function */
void video_thread_entry(void)
{
    UINT status;

    memcpy(g_display_fb_foreground, p_resource_banner, sizeof(g_display_fb_foreground));

    status = gx_system_initialize();
    if (GX_SUCCESS != status)
    {
        __BKPT(0);
    }

    /* Open GUIX Adaptation Framework for Synergy */
    status = g_sf_el_gx.p_api->open(g_sf_el_gx.p_ctrl, g_sf_el_gx.p_cfg);
    if (SSP_SUCCESS != status)
    {
        __BKPT(0);
    }

    /* Set up GUIX Renderer */
    status = gx_studio_display_configure(0, g_sf_el_gx.p_api->setup, 0, 0, &p_window_root);
    if (GX_SUCCESS != status)
    {
        __BKPT(0);
    }

    /* Initialize drawing canvas created by GLCDC */
    status = g_sf_el_gx.p_api->canvasInit(g_sf_el_gx.p_ctrl, p_window_root);
    if (SSP_SUCCESS != status)
    {
        __BKPT(0);
    }

    guix_setup(p_window_root);

    g_ioport.p_api->pinWrite(IOPORT_PORT_10_PIN_03, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(IOPORT_PORT_10_PIN_05, IOPORT_LEVEL_HIGH);

    while (1)
    {
        sf_touch_panel_payload_t * p_message = NULL;

        status = g_sf_message.p_api->pend(g_sf_message.p_ctrl, &video_thread_message_queue,
                                        (sf_message_header_t **) &p_message, TX_WAIT_FOREVER);
        if (SSP_SUCCESS == status)
        {
            if ((SF_MESSAGE_EVENT_CLASS_TOUCH == p_message->header.event_b.class_code) &&
                (SF_MESSAGE_EVENT_NEW_DATA    == p_message->header.event_b.code)       &&
                (0                            == p_message->header.event_b.class_instance))
            {
                GX_EVENT gxe = {0};

                switch (p_message->event_type)
                {
                    case SF_TOUCH_PANEL_EVENT_DOWN:
                    {
                        gxe.gx_event_type = GX_EVENT_PEN_DOWN;
                        break;
                    }

                    case SF_TOUCH_PANEL_EVENT_UP:
                    {
                        gxe.gx_event_type = GX_EVENT_PEN_UP;
                        break;
                    }

                    case SF_TOUCH_PANEL_EVENT_HOLD:
                    case SF_TOUCH_PANEL_EVENT_MOVE:
                    {
                        gxe.gx_event_type = GX_EVENT_PEN_DRAG;
                        break;
                    }

                    default:
                    {
                        gxe.gx_event_type = GX_NULL;
                        break;
                    }
                }

                if (GX_NULL != gxe.gx_event_type)
                {
                    gxe.gx_event_payload.gx_event_pointdata.gx_point_x = (GX_VALUE) (p_message->x);
                    gxe.gx_event_payload.gx_event_pointdata.gx_point_y = (GX_VALUE) (p_message->y);

                    gx_system_event_send(&gxe);
                }
            }

            g_sf_message.p_api->bufferRelease(g_sf_message.p_ctrl, (sf_message_header_t *) p_message,
                                               SF_MESSAGE_RELEASE_OPTION_ACK);
        }
    }
}
