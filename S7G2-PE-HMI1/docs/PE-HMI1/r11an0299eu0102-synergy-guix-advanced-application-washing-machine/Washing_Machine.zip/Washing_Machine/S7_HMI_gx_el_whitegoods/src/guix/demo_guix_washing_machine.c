/* This is a small demo of the high-performance GUIX graphics framework. */

#include "demo_guix_washing_machine.h"

/* Define prototypes.   */
#if defined(_RENESAS_SYNERGY_)
#include "hal_data.h"
VOID guix_setup(GX_WINDOW_ROOT * root);
#else
VOID  guix_setup(void);
extern UINT win32_graphics_driver_setup_24xrgb(GX_DISPLAY *display);
#endif
VOID clock_update();
VOID *memory_allocate(ULONG size);
VOID main_screen_widgets_enable_disable(INT status);

extern GX_STUDIO_DISPLAY_INFO demo_guix_washing_machine_display_table[];

TX_BYTE_POOL       memory_pool;

#define POWER_ON_OFF_TIMER  10
#define CLOCK_TIMER         20

#define SCRATCHPAD_PIXELS (MAIN_DISPLAY_X_RESOLUTION * MAIN_DISPLAY_Y_RESOLUTION)

/* Define memory for memory pool. */
#if defined(_RENESAS_SYNERGY_)
GX_COLOR           scratchpad[SCRATCHPAD_PIXELS] BSP_PLACE_IN_SECTION(".sdram");
#else
GX_COLOR           scratchpad[SCRATCHPAD_PIXELS];
#endif

GX_WINDOW_ROOT    *root;

/* Define canvas blend alpha. */
INT                blend_alpha = 255;

/* Define canvas blend alpha increment. */
INT                blend_alpha_increment = 0;

/* Define power on/off callback. */
VOID             (*power_on_callback)() = GX_NULL;
VOID             (*power_off_callback)() = GX_NULL;


const GX_CHAR *day_names[7] = {
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
};

const GX_CHAR *month_names[12] = {
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
};

GX_WIDGET *main_screen_enable_disable_widgets[] = {
    (GX_WIDGET *)&main_screen.main_screen_pixelmap_slider,
    (GX_WIDGET *)&main_screen.main_screen_page_name,
    (GX_WIDGET *)&main_screen.main_screen_button_washer_on,
    (GX_WIDGET *)&main_screen.main_screen_button_garments,
    (GX_WIDGET *)&main_screen.main_screen_button_water_level,
    (GX_WIDGET *)&main_screen.main_screen_button_temperature,
    GX_NULL
};

/******************************************************************************************/
/* Define memory allocator function.                                                     */
/******************************************************************************************/
VOID *memory_allocate(ULONG size)
{
    VOID *memptr;

    if (tx_byte_allocate(&memory_pool, &memptr, size, TX_NO_WAIT) == TX_SUCCESS)
    {
        return memptr;
    }
    return NULL;
}

/******************************************************************************************/
/* Define memory de-allocator function.                                                   */
/******************************************************************************************/
void memory_free(VOID *mem)
{
    tx_byte_release(mem);
}

#if !defined(_RENESAS_SYNERGY_)
/******************************************************************************************/
/* Application entry.                                                                     */
/******************************************************************************************/
int main(int argc, char ** argv)
{
    tx_kernel_enter();
    return(0);
}

/******************************************************************************************/
/* Define tx_application_define function.                                                 */
/******************************************************************************************/
VOID tx_application_define(void *first_unused_memory)
{

    /* create byte pool. */
    tx_byte_pool_create(&memory_pool, "scratchpad", scratchpad,
        SCRATCHPAD_PIXELS * sizeof(GX_COLOR));

    guix_setup();
}
#endif

#if defined(_RENESAS_SYNERGY_)
VOID guix_setup(GX_WINDOW_ROOT * p_root)
{
    root = p_root;

    tx_byte_pool_create(&memory_pool, "scratchpad", scratchpad,
        SCRATCHPAD_PIXELS * sizeof(GX_COLOR));

#else
/******************************************************************************************/
VOID  guix_setup()
{

    /* Initialize GUIX. */
    gx_system_initialize();

    /* Configure display. */
    gx_studio_display_configure(MAIN_DISPLAY, win32_graphics_driver_setup_24xrgb,
        LANGUAGE_ENGLISH, MAIN_DISPLAY_THEME_1, &root);

#endif

    /* install our memory allocator and de-allocator */
    gx_system_memory_allocator_set(memory_allocate, memory_free);

    /* Create the main screen and attach it to root window. */
    gx_studio_named_widget_create("main_screen", (GX_WIDGET *)root, GX_NULL);

    /* Create washer mode radial slider. */
    washer_mode_radial_slider_create();

    /* Create garments window. */
    gx_studio_named_widget_create("garments_window", GX_NULL, GX_NULL);

    /* Create garments mode radial slider. */
    garments_mode_radial_slider_create();

    /* Create water level window. */
    gx_studio_named_widget_create("water_level_window", GX_NULL, GX_NULL);

    /* Create temperature window. */
    gx_studio_named_widget_create("temperature_window", GX_NULL, GX_NULL);

    /* Create temperature radial slider. */
    temperature_radial_slider_create();

    /* Show the root window to make it and main screen visible.  */
    gx_widget_show(root);

    /* Let GUIX run */
    gx_system_start();
}

/******************************************************************************************/
/* Override the default event processing of "main_screen" to handle signals from my child */
/* widgets.                                                                               */
/******************************************************************************************/
UINT main_screen_event_process(GX_WINDOW *window, GX_EVENT *event_ptr)
{
    GX_CHAR *text;

    switch (event_ptr->gx_event_type)
    {
    case GX_EVENT_SHOW:
        clock_update();

        /* Init washer on page. */
        washer_on_page_init();
        power_on_callback = washer_on_page_init;
        power_off_callback = washer_on_page_power_off;

        /* Start a timer to update current time. */
        gx_system_timer_start((GX_WIDGET *)window, CLOCK_TIMER, GX_TICKS_SECOND, GX_TICKS_SECOND);

        /* Call default event process. */
        gx_window_event_process(window, event_ptr);
        break;

    case GX_EVENT_PEN_UP:
        if (washer_mode_radial_slider.gx_widget_style & GX_STYLE_BUTTON_PUSHED)
        {
            /* If washer_mode_radial_slider is still in pushed status, call its event process funtion to 
            move the needle to right position. */
            washer_mode_radial_slider.gx_widget_event_process_function((GX_WIDGET *)&washer_mode_radial_slider, event_ptr);
        }
        else if (garments_mode_radial_slider.gx_widget_style & GX_STYLE_BUTTON_PUSHED)
        {
            /* If garments_mode_radial_slider is still in pushed status, call its event process funtion to
            move the needle to right position. */
            garments_mode_radial_slider.gx_widget_event_process_function((GX_WIDGET *)&garments_mode_radial_slider, event_ptr);
        }
        gx_window_event_process(window, event_ptr);
        break;

    case GX_SIGNAL(ID_BTN_WASHER_ON, GX_EVENT_RADIO_SELECT):
        /* Attach washer on page. */
        gx_widget_attach((GX_WIDGET *)window, &main_screen.main_screen_washer_on_window);

        /* Init washer on page. */
        washer_on_page_init();
        power_on_callback = washer_on_page_init;
        power_off_callback = washer_on_page_power_off;

        /* Set washer on label text id to "STRING_ID_PAUSE". */
        gx_prompt_text_id_set(&main_screen.main_screen_washer_on_label, GX_STRING_ID_PAUSE);
        break;

    case GX_SIGNAL(ID_BTN_WASHER_ON, GX_EVENT_RADIO_DESELECT):
        /* Dettach washer on page. */
        gx_widget_detach(&main_screen.main_screen_washer_on_window);

        /* Set washer on button label text id to "STRING_ID_START". */
        gx_prompt_text_id_set(&main_screen.main_screen_washer_on_label, GX_STRING_ID_START);

        /* Set washer on button icon id to "ICON_START". */
        gx_icon_pixelmap_set(&main_screen.main_screen_washer_on_icon, GX_PIXELMAP_ID_BUTTON_ICON_START, GX_NULL);
        break;

    case GX_SIGNAL(ID_BTN_GARMENTS, GX_EVENT_RADIO_SELECT):
        /* Attach garments page. */
        gx_widget_attach((GX_WIDGET *)window, &garments_window);

        /* Init garments page. */
        garments_page_init();
        power_on_callback = garments_page_init;
        power_off_callback = garments_page_power_off;
        break;

    case GX_SIGNAL(ID_BTN_GARMENTS, GX_EVENT_RADIO_DESELECT):
        /* Detach garments page. */
        gx_widget_detach(&garments_window);
        break;

    case GX_SIGNAL(ID_BTN_WATER_LEVEL, GX_EVENT_RADIO_SELECT):
        /* Attach water level page. */
        gx_widget_attach((GX_WIDGET *)window, &water_level_window);

        /* Init water level page. */
        water_level_page_init();
        power_on_callback = water_level_page_init;
        power_off_callback = water_level_page_power_off;
        break;

    case GX_SIGNAL(ID_BTN_WATER_LEVEL, GX_EVENT_RADIO_DESELECT):
        /* Detach water level page. */
        gx_widget_detach(&water_level_window);
        break;

    case GX_SIGNAL(ID_BTN_TEMPERATURE, GX_EVENT_RADIO_SELECT):
        /* Attach temperature page. */
        gx_widget_attach((GX_WIDGET *)window, &temperature_window);

        /* Init temperature page. */
        temperature_page_init();
        power_on_callback = temperature_page_init;
        power_off_callback = temperature_page_power_off;
        break;

    case GX_SIGNAL(ID_BTN_TEMPERATURE, GX_EVENT_RADIO_DESELECT):
        /* Dettach temperature page. */
        gx_widget_detach(&temperature_window);
        break;

    case GX_SIGNAL(ID_BTN_POWER_ON_OFF, GX_EVENT_CLICKED):
        /* Get power on/off button label text. */
        gx_prompt_text_get(&main_screen.main_screen_power_off_label, (GX_CONST GX_CHAR**)&text);

        if (strcmp(text, "Power Off") == 0)
        {
            /* The main screen is going to power off. */
            blend_alpha_increment = -4;
            gx_system_timer_start((GX_WIDGET *)window, POWER_ON_OFF_TIMER, 1, 1);
            gx_prompt_text_id_set(&main_screen.main_screen_power_off_label, GX_STRING_ID_POWER_ON);

            if (power_off_callback)
            {
                power_off_callback();
                main_screen_widgets_enable_disable(POWER_OFF);
            }
        }
        else
        {
            /* The main screen is going to power on. */
            blend_alpha_increment = 4;
            gx_system_timer_start((GX_WIDGET *)window, POWER_ON_OFF_TIMER, 1, 1);
            gx_prompt_text_id_set(&main_screen.main_screen_power_off_label, GX_STRING_ID_POWER_OFF);

            if (power_on_callback)
            {
                power_on_callback();
                main_screen_widgets_enable_disable(POWER_ON);
            }
        }
        break;

    case GX_EVENT_TIMER:
        if (event_ptr->gx_event_payload.gx_event_timer_id == POWER_ON_OFF_TIMER)
        {
            blend_alpha += blend_alpha_increment;

            if (blend_alpha >= 255 || blend_alpha <= 160)
            {
                gx_system_timer_stop((GX_WIDGET *)&main_screen, POWER_ON_OFF_TIMER);

                if (blend_alpha >= 255)
                {
                    blend_alpha = 255;
                }
                else
                {
                    blend_alpha = 160;
                }
            }

            gx_system_dirty_mark((GX_WIDGET *)&main_screen);
        }
        else if (event_ptr->gx_event_payload.gx_event_timer_id == CLOCK_TIMER)
        {
            /* Update current time. */
            clock_update();
        }
        break;

    default:
        return gx_window_event_process(window, event_ptr);
    }

    return 0;
}

/******************************************************************************************/
/* A custom prompt draw function that draws the widget with specified blend alpha.        */
/******************************************************************************************/
VOID prompt_alpha_draw(GX_PROMPT *prompt)
{
    GX_BRUSH *brush;

    /* Get context brush. */
    gx_context_brush_get(&brush);

    /* Set brush alpha. */
    brush->gx_brush_alpha = (UCHAR)blend_alpha;

    gx_prompt_draw(prompt);
}

/******************************************************************************************/
/* A custom pixelmap button draw function that draws the widget with specified blend      */
/* alpha.                                                                                 */
/******************************************************************************************/
VOID pixelmap_button_alpha_draw(GX_PIXELMAP_BUTTON *button)
{
    GX_BRUSH *brush;

    /* Get context brush. */
    gx_context_brush_get(&brush);

    brush->gx_brush_alpha = (UCHAR)blend_alpha;

    gx_pixelmap_button_draw(button);
}

/******************************************************************************************/
/* A custom pixlemap slider draw function that draws the widget with specified blend      */
/* alpha.                                                                                 */
/******************************************************************************************/
VOID pixelmap_slider_alpha_draw(GX_PIXELMAP_SLIDER *slider)
{
    GX_BRUSH *brush;

    /* Get context brush. */
    gx_context_brush_get(&brush);

    brush->gx_brush_alpha = (UCHAR)blend_alpha;

    gx_pixelmap_slider_draw(slider);
}

/******************************************************************************************/
/* A custom wubdiw draw function that draws the widget with specified blend alpha.        */
/******************************************************************************************/
VOID window_alpha_draw(GX_WINDOW *window)
{
    GX_BRUSH *brush;

    /* Get context brush. */
    gx_context_brush_get(&brush);

    brush->gx_brush_alpha = (UCHAR)blend_alpha;

    gx_window_draw(window);
}

/******************************************************************************************/
/* Update clock of main screen.                                                           */
/******************************************************************************************/
VOID clock_update()
{
#ifdef WIN32
    GX_CHAR time_string[6];
    GX_CHAR am_pm[3];
    GX_CHAR date_string[20];

    SYSTEMTIME local_time;
    GetLocalTime(&local_time);
    if (local_time.wHour < 12)
    {
        sprintf(time_string, "%d:%02d", local_time.wHour, local_time.wMinute);
        GX_STRCPY(am_pm, "AM");
    }
    else
    {
        sprintf(time_string, "%d:%02d", local_time.wHour - 12, local_time.wMinute);
        GX_STRCPY(am_pm, "PM");
    }
    gx_prompt_text_set(&main_screen.main_screen_time, time_string);
    gx_prompt_text_set(&main_screen.main_screen_am_pm, am_pm);
    gx_prompt_text_set(&main_screen.main_screen_day_of_week, day_names[local_time.wDayOfWeek]);

    sprintf(date_string,  "%s %02d, %d", month_names[local_time.wMonth - 1], local_time.wDay, local_time.wYear);
    gx_prompt_text_set(&main_screen.main_screen_date, date_string);

#else
#endif
}

VOID main_screen_widgets_enable_disable(INT status)
{
    GX_WIDGET *widget;
    INT        index = 0;
    if (status == POWER_ON)
    {
        widget = main_screen_enable_disable_widgets[index];

        while (widget)
        {
            gx_widget_style_add(widget, GX_STYLE_ENABLED);
            widget = main_screen_enable_disable_widgets[index];
            index++;
        }
    }
    else
    {
        widget = main_screen_enable_disable_widgets[index];

        while (widget)
        {
            gx_widget_style_remove(widget, GX_STYLE_ENABLED);
            widget = main_screen_enable_disable_widgets[index];
            index++;
        }
    }
}

VOID widget_enable_disable(GX_WIDGET *widget, INT status)
{
    GX_WIDGET *child = widget->gx_widget_first_child;

    while (child)
    {
        widget_enable_disable(child, status);
        child = child->gx_widget_next;
    }

    if (status == POWER_ON)
    {
        gx_widget_style_add(widget, GX_STYLE_ENABLED);
    }
    else
    {
        gx_widget_style_remove(widget, GX_STYLE_ENABLED);
    }
}
