#include "radial_slider.h"

#define RANGE_VAL(_a) if (_a > 0xff) {_a = 0xff; } \
        else if (_a < -0xff) {_a = -0xff; }

/* Declare prototypes. */
UINT radial_slider_animation_start(RADIAL_SLIDER *slider, GX_VALUE target_value);
UINT radial_slider_animation_update(RADIAL_SLIDER *slider);
UINT radial_slider_animation_update_callback_set(RADIAL_SLIDER *slider, VOID(*animation_update_callback)(INT remain_steps));
UINT radial_slider_create(RADIAL_SLIDER *slider, GX_CONST GX_CHAR *name, GX_WIDGET *parent,
    RADIAL_SLIDER_INFO *info, ULONG style, USHORT id, GX_RECTANGLE *size);
VOID radial_slider_draw(RADIAL_SLIDER *slider);
UINT radial_slider_event_process(RADIAL_SLIDER *slider, GX_EVENT *event_ptr);
VOID radial_slider_needle_rectangle_get(RADIAL_SLIDER *slider, GX_RECTANGLE *rectangle);
UINT radial_slider_needle_pixelmap_set(RADIAL_SLIDER *slider, GX_RESOURCE_ID needle_pixelmap);
UINT radial_slider_target_value_calculate(RADIAL_SLIDER *slider, GX_VALUE new_value);
UINT radial_slider_value_set(RADIAL_SLIDER *slider, GX_VALUE new_value);
UINT radial_slider_value_calculate(RADIAL_SLIDER *slider, GX_POINT point, GX_VALUE *return_value);

/* Implement a radial slider widget. */

/******************************************************************************************/
/* Radial slider create function.                                                         */
/******************************************************************************************/
UINT radial_slider_create(RADIAL_SLIDER *slider, GX_CONST GX_CHAR *name, GX_WIDGET *parent,
    RADIAL_SLIDER_INFO *info, ULONG style, USHORT id, GX_RECTANGLE *size)
{
UINT         status;

    /* Call the widget create function. */
    status = gx_widget_create((GX_WIDGET *)slider, name, parent, style, id, size);

    if (status == GX_SUCCESS)
    {
        slider->info = *info;
        slider->gx_widget_type = USER_TYPE_RADIAL_SLIDER;
        slider->gx_widget_draw_function = (VOID(*)(GX_WIDGET *))radial_slider_draw;
        slider->gx_widget_event_process_function = (UINT(*)(GX_WIDGET *, GX_EVENT *event_ptr))radial_slider_event_process;
        slider->animation_update_callback = GX_NULL;
        slider->status = STATUS_NONE;
        slider->current_val = 0;

        if (slider->info.angle_list)
        {
            slider->current_val = slider->info.angle_list[0];
        }

        slider->target_val = slider->current_val;
    }

    return status;
}

/******************************************************************************************/
/* Calculate the bounding rectangle of needle.                                            */
/******************************************************************************************/
VOID radial_slider_needle_rectangle_get(RADIAL_SLIDER *slider, GX_RECTANGLE *rectangle)
{
    RADIAL_SLIDER_INFO *info = &slider->info;
    GX_PIXELMAP *map;
    INT xpos;
    INT ypos;

    /* pick needle pixelmap. */
    gx_widget_pixelmap_get(slider, info->needle_pixelmap, &map);
    
    /* calculate sin and cos value of current angle value. */
    xpos = info->radius * gx_utility_math_cos(slider->current_val << 8) >> 8;
    ypos = info->radius * gx_utility_math_sin(slider->current_val << 8) >> 8;

    /* calculate needle position. */
    xpos += info->xcenter;
    ypos = info->ycenter - ypos;

    xpos -= map->gx_pixelmap_width >> 1;
    ypos -= map->gx_pixelmap_height >> 1;

    xpos += slider->gx_widget_size.gx_rectangle_left;
    ypos += slider->gx_widget_size.gx_rectangle_top;

    /* define needle rectangle. */
    gx_utility_rectangle_define(rectangle, (GX_VALUE)xpos, (GX_VALUE)ypos, (GX_VALUE)(xpos + map->gx_pixelmap_width), (GX_VALUE)(ypos + map->gx_pixelmap_height));
}

/******************************************************************************************/
/* Draw radial slider.                                                                    */
/******************************************************************************************/
VOID radial_slider_draw(RADIAL_SLIDER *slider)
{
    GX_PIXELMAP *map = GX_NULL;
    GX_RECTANGLE size;

    /* Call default widget draw. */
    gx_widget_draw((GX_WIDGET *)slider);

    /* Pick needle pixelmap. */
    gx_context_pixelmap_get(slider->info.needle_pixelmap, &map);
    if (map)
    {
        /* Get needle bounding rectangle. */
        radial_slider_needle_rectangle_get(slider, &size);

        /* Draw needle. */
        gx_canvas_pixelmap_draw(size.gx_rectangle_left, size.gx_rectangle_top, map);
    }

    /* Draw children widgets. */
    gx_widget_children_draw((GX_WIDGET *)slider);
}

/******************************************************************************************/
/* Process event for radial slider widget.                                                */
/******************************************************************************************/
UINT radial_slider_event_process(RADIAL_SLIDER *slider, GX_EVENT *event_ptr)
{
    INT xpos;
    INT ypos;
    INT dist;
    GX_VALUE new_value;
    RADIAL_SLIDER_INFO *info = &slider->info;
    GX_POINT *point;
    GX_RECTANGLE rectangle;

    switch (event_ptr->gx_event_type)
    {
    case GX_EVENT_PEN_DOWN:
        if (slider->status == STATUS_NONE)
        {
            point = &event_ptr->gx_event_payload.gx_event_pointdata;

            /* Clean styles. */
            slider->gx_widget_style &= ~GX_STYLE_BUTTON_PUSHED;

            /* Record pen down point. */
            slider->pen_down_point = *point;

            /* Get current needle bounding rectangle. */
            radial_slider_needle_rectangle_get(slider, &rectangle);

            /* Check if click point is inside needle area. */
            if (gx_utility_rectangle_point_detect(&rectangle, *point))
            {
                slider->status = STATUS_TRACKING;

                slider->gx_widget_style |= GX_STYLE_BUTTON_PUSHED;
            }
            else
            {
                /* Check if the click down point is inside tracking area. */

                xpos = point->gx_point_x - slider->gx_widget_size.gx_rectangle_left;
                ypos = point->gx_point_y - slider->gx_widget_size.gx_rectangle_top;

                /* Calculate the distacnce from click point to tracking center. */
                dist = (INT)(gx_utility_math_sqrt((UINT)(((xpos - info->xcenter) * (xpos - info->ycenter) +
                    (ypos - info->ycenter) * (ypos - info->ycenter)))));

                if ((info->radius - info->track_width / 2 <= dist) && (dist <= info->radius + info->track_width / 2))
                {
                    /* Click point is inside tracking area.  */
                    slider->gx_widget_style |= GX_STYLE_BUTTON_PUSHED;
                }
            }
        }
        break;

    case GX_EVENT_PEN_DRAG:
        /* move my needle */
        if (slider->status == STATUS_TRACKING)
        {
            /* Calcualte new slider value. */
            radial_slider_value_calculate(slider, event_ptr->gx_event_payload.gx_event_pointdata, &new_value);

            /* Check if the new value is inside valide range. */
            if ((new_value >= slider->info.min_angle) && (new_value <= slider->info.max_angle))
            {
                radial_slider_value_set(slider, new_value);
            }
        }
        break;

    case GX_EVENT_PEN_UP:
        if (slider->gx_widget_style & GX_STYLE_BUTTON_PUSHED)
        {
            slider->gx_widget_style &= ~GX_STYLE_BUTTON_PUSHED;

            point = &event_ptr->gx_event_payload.gx_event_pointdata;

            if (slider->status == STATUS_TRACKING ||
                ((point->gx_point_x - slider->pen_down_point.gx_point_x) < 5 &&
                (point->gx_point_y - slider->pen_down_point.gx_point_y < 5)))
            {
                if (slider->status == STATUS_TRACKING)
                {
                    /* Slider needle is under tracking, calculate target value with current value. */
                    radial_slider_target_value_calculate(slider, slider->current_val);
                }
                else
                {
                    /* Calculate new angle value with current point. */
                    radial_slider_value_calculate(slider, *point, &new_value);

                    /* Calcualte target value with new value. */
                    radial_slider_target_value_calculate(slider, new_value);
                }

                /* Start animation to move needle from current position to target position. */
                radial_slider_animation_start(slider, slider->target_val);
            }

            slider->status = STATUS_NONE;
        }
        break;

    case GX_EVENT_TIMER:
        if (event_ptr->gx_event_payload.gx_event_timer_id == RADIAL_SLIDER_ANIMATION_TIMER)
        {
            radial_slider_animation_update(slider);
        }
        else
        {
            gx_widget_event_process((GX_WIDGET *)slider, event_ptr);
        }
        break;

    default:
        return gx_widget_event_process((GX_WIDGET *)slider, event_ptr);
    }

    return GX_SUCCESS;
}

/******************************************************************************************/
/* Calcualte slider value according to pen point.                                         */
/******************************************************************************************/
UINT radial_slider_value_calculate(RADIAL_SLIDER *slider, GX_POINT point, GX_VALUE *return_value)
{
RADIAL_SLIDER_INFO *info;
INT                 new_value;
INT                 dist;
INT                 x_dist;
INT                 y_dist;
INT                 x_center;
INT                 y_center;

    info = &slider->info;

    x_center = slider->gx_widget_size.gx_rectangle_left + info->xcenter;
    y_center = slider->gx_widget_size.gx_rectangle_top + info->ycenter;

    x_dist = (INT)(point.gx_point_x - x_center);
    y_dist = (INT)(point.gx_point_y - y_center);

    dist = (x_dist * x_dist) + (y_dist * y_dist);
    dist = (INT)_gx_utility_math_sqrt((UINT)dist);

    if (point.gx_point_y <= y_center)
    {
        x_dist = (x_dist << 8) / dist;
        RANGE_VAL(x_dist);

        /* The needle is between [0, 180].  */
        new_value = gx_utility_math_acos(x_dist);
    }
    else
    {
        y_dist = (y_dist << 8) / dist;
        RANGE_VAL(y_dist);

        /* The needle is between [180, 360]  */
        new_value = gx_utility_math_asin(y_dist);

        if (point.gx_point_x < x_center)
        {
            new_value = 180 + new_value;
        }
        else
        {
            new_value = 360 - new_value;
        }
    }

    /* Range value inside specified [-90, 270]*/
    if (new_value > 270)
    {
        new_value = new_value - 360;
    }
    else if (new_value < -90)
    {
        new_value = new_value + 360;
    }

    *return_value = (GX_VALUE)new_value;

    return(GX_SUCCESS);
}

/******************************************************************************************/
/* Set new slider value.                                                                  */
/******************************************************************************************/
UINT radial_slider_value_set(RADIAL_SLIDER *slider, GX_VALUE new_value)
{
    GX_EVENT slider_value_event;

    if (new_value != slider->current_val)
    {
        slider->current_val = new_value;

        if (slider->gx_widget_status & GX_STATUS_VISIBLE)
        {
            gx_system_dirty_mark((GX_WIDGET *)slider);
        }

        memset(&slider_value_event, 0, sizeof(GX_EVENT));
        slider_value_event.gx_event_sender = slider->gx_widget_id;
        slider_value_event.gx_event_target = slider->gx_widget_parent;
        slider_value_event.gx_event_type = USER_EVENT_SLIDER_VALUE;
        slider_value_event.gx_event_payload.gx_event_intdata[0] = (int)slider->current_val;

        /* Send value set event. */
        gx_system_event_fold(&slider_value_event);
    }

    return (GX_SUCCESS);
}

/******************************************************************************************/
/* If an angle list provided, retrieve the angle that is nearest to the supplied value.   */
/******************************************************************************************/
UINT radial_slider_target_value_calculate(RADIAL_SLIDER *slider, GX_VALUE new_value)
{
    INT index;
    GX_VALUE min_value;
    GX_VALUE max_value;
    RADIAL_SLIDER_INFO *info = &slider->info;

    index = 0;

    if (info->angle_list)
    {
        /* If an angle list is supplied, set the target value to one of the values
        in angle list that is nearest to the given value. */
        while (index < info->list_count)
        {
            if (index == 0)
            {
                min_value = (GX_VALUE)((info->angle_list[index] - 90) >> 1);
            }
            else
            {
                min_value = (GX_VALUE)((info->angle_list[index] + info->angle_list[index - 1]) >> 1);
            }

            if (index == info->list_count - 1)
            {
                max_value = (GX_VALUE)((info->angle_list[index] + 270) << 1);
            }
            else
            {
                max_value = (GX_VALUE)((info->angle_list[index] + info->angle_list[index + 1]) >> 1);
            }

            if ((new_value >= min_value) && (new_value <= max_value))
            {
                slider->target_val = info->angle_list[index];
                break;
            }

            index++;
        }
    }
    else
    {
        if (new_value >= -90 && new_value <= info->min_angle)
        {
            slider->target_val = info->min_angle;
        }
        else if (new_value >= info->max_angle && new_value <= 270)
        {
            slider->target_val = info->max_angle;
        }
        else
        {
            slider->target_val = new_value;
        }
    }

    return GX_SUCCESS;
}

/******************************************************************************************/
/* Start an animation to move needle from current value to target value.                  */
/******************************************************************************************/
UINT radial_slider_animation_start(RADIAL_SLIDER *slider, GX_VALUE target_value)
{
    GX_EVENT slider_value_event;
    slider->target_val = target_value;
    slider->status = STATUS_LANDING;

    memset(&slider_value_event, 0, sizeof(GX_EVENT));
    slider_value_event.gx_event_sender = slider->gx_widget_id;
    slider_value_event.gx_event_target = slider->gx_widget_parent;
    slider_value_event.gx_event_type = USER_EVENT_ANIMATION_START;
    slider_value_event.gx_event_payload.gx_event_intdata[0] = (int)target_value;

    /* Send animation complete event. */
    gx_system_event_fold(&slider_value_event);

    gx_system_timer_start((GX_WIDGET *)slider, RADIAL_SLIDER_ANIMATION_TIMER, 1, 1);

    return (GX_SUCCESS);
}

/******************************************************************************************/
/* Animation update function that is called for each animation step.                      */
/******************************************************************************************/
UINT radial_slider_animation_update(RADIAL_SLIDER *slider)
{
    GX_VALUE current_val = slider->current_val;
    INT move_increment;
    GX_EVENT slider_value_event;
    GX_BOOL finished = GX_FALSE;

    if (current_val < slider->target_val)
    {
        if (current_val + 30 < slider->target_val)
        {
            move_increment = 10;
        }
        else
        {
            move_increment = 1;
        }

        if (current_val + move_increment >= slider->target_val)
        {
            finished = GX_TRUE;
            current_val = slider->target_val;
        }
        else
        {
            current_val = (GX_VALUE)(current_val + move_increment);
        }
    }
    else if(current_val > slider->target_val)
    {
        if (current_val - 30 > slider->target_val)
        {
            move_increment = 10;
        }
        else
        {
            move_increment = 1;
        }

        if (current_val - move_increment <= slider->target_val)
        {
            finished = GX_TRUE;
            current_val = slider->target_val;
        }
        else
        {
            current_val = (GX_VALUE)(current_val - move_increment);
        }
    }
    else
    {
        finished = GX_TRUE;
    }

    /* set radial slider value. */
    radial_slider_value_set(slider, current_val);

    if (slider->animation_update_callback)
    {
        /* Call callback function. */
        slider->animation_update_callback(current_val);
    }

    if (finished)
    {
        slider->status = STATUS_NONE;
        gx_system_timer_stop((GX_WIDGET *)slider, RADIAL_SLIDER_ANIMATION_TIMER);

        memset(&slider_value_event, 0, sizeof(GX_EVENT));
        slider_value_event.gx_event_sender = slider->gx_widget_id;
        slider_value_event.gx_event_target = slider->gx_widget_parent;
        slider_value_event.gx_event_type = USER_EVENT_ANIMATION_COMPLETE;
        slider_value_event.gx_event_payload.gx_event_intdata[0] = (int)current_val;

        /* Send animation complete event. */
        gx_system_event_fold(&slider_value_event);
    }

    return GX_SUCCESS;
}

/******************************************************************************************/
/* Set additional animation upate function that to be called during every animation step. */
/******************************************************************************************/
UINT radial_slider_animation_update_callback_set(RADIAL_SLIDER *slider, VOID(*animation_update_callback)(INT current_val))
{
    /* the callback function will be called when slider animation update is called. */
    slider->animation_update_callback = animation_update_callback;

    return GX_SUCCESS;
}

/******************************************************************************************/
/* Set slider needle pixelmap.                                                            */
/******************************************************************************************/
UINT radial_slider_needle_pixelmap_set(RADIAL_SLIDER *slider, GX_RESOURCE_ID needle_pixelmap)
{
    /* set needle pixelmap. */
    slider->info.needle_pixelmap = needle_pixelmap;

    if (slider->status && GX_STATUS_VISIBLE)
    {
        gx_system_dirty_mark((GX_WIDGET *)slider);
    }

    return GX_SUCCESS;
}
