/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
#include "usb_cdc_acm_host_thread.h"

#ifdef SEMI_HOSTING
#include "stdio.h"
#ifdef __GNUC__
void initialise_monitor_handles(void);
#endif
#endif

/***********************************************************************************************************************
    Private function prototypes
 ***********************************************************************************************************************/

/***********************************************************************************************************************
    Private global variables
 ***********************************************************************************************************************/
/* A pointer to store CDC-ACM instance. */
static UX_HOST_CLASS_CDC_ACM* p_cdc_acm = UX_NULL;

#define UX_DEMO_BUFFER_SIZE (128)

/* CDC-ACM reception data buffer. */
static UCHAR buffer[UX_DEMO_BUFFER_SIZE];

ULONG error_count = 0;

#define CDCACM_FLAG ((ULONG)0x0001)


UINT ux_host_usr_event_notification(ULONG event, UX_HOST_CLASS * host_class, VOID * instance)
{
    if(_ux_utility_memory_compare(_ux_system_host_class_cdc_acm_name, host_class,
                                   _ux_utility_string_length_get(_ux_system_host_class_cdc_acm_name))
                                   ==UX_SUCCESS)
    {
        if(event==UX_DEVICE_INSERTION) /* Check if there is a device insertion. */
        {
            p_cdc_acm = (UX_HOST_CLASS_CDC_ACM*)instance;
            if(p_cdc_acm->ux_host_class_cdc_acm_interface->ux_interface_descriptor.bInterfaceClass!=
                    UX_HOST_CLASS_CDC_DATA_CLASS)
            {
                /* It seems the DATA class is on the second interface. Or we hope !  */
                p_cdc_acm = p_cdc_acm->ux_host_class_cdc_acm_next_instance;

                /* Check again this interface, if this is not the data interface, we give up.  */
                if(p_cdc_acm->ux_host_class_cdc_acm_interface->ux_interface_descriptor.bInterfaceClass!=
                        UX_HOST_CLASS_CDC_DATA_CLASS)
                {
                    /* We did not find a proper data interface. */
                    p_cdc_acm = UX_NULL;
                }
            }

            if(p_cdc_acm!=UX_NULL)
            {
                tx_event_flags_set(&g_cdcacm_activate_event_flags0, CDCACM_FLAG, TX_OR);
            }
        }
        else if(event==UX_DEVICE_REMOVAL) /* Check if there is a device removal. */
        {
            tx_event_flags_set(&g_cdcacm_activate_event_flags0, ~CDCACM_FLAG, TX_AND);
            p_cdc_acm = UX_NULL;
        }
    }

    return UX_SUCCESS;
}

/* CDCACM Host Thread entry function */
void usb_cdc_acm_host_thread_entry(void)
{
    ULONG status;
    ULONG actual_flags;
    ULONG actual_length;
    ULONG send_count;

#ifdef SEMI_HOSTING
#ifdef __GNUC__
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        initialise_monitor_handles(); /* function to enable printf() in debug console*/
    }   
#endif
#endif

    error_count = 0;
    send_count = 0;

    while (1)
    {
        status = tx_event_flags_get(&g_cdcacm_activate_event_flags0, CDCACM_FLAG,  TX_OR, &actual_flags,  TX_WAIT_FOREVER);
        if(p_cdc_acm != UX_NULL)
        {
            tx_thread_sleep(100);

            buffer[0] = 'A';
            buffer[1] = 'T';
            buffer[2] = '\r';
            buffer[3] = '\n';

#ifdef SEMI_HOSTING
            if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
            {
                printf("send_count: %ld\n", send_count+1);
            }
#endif

            /* Send the AT command.  */
            status = ux_host_class_cdc_acm_write(p_cdc_acm, buffer, 4, &actual_length);
            if(status)
            {
                error_count++;
#ifdef SEMI_HOSTING
                if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
                {
                    printf("ux_host_class_cdc_acm_write failed. err = %ld\n", status);
                }
#endif
                tx_thread_sleep(200);
                continue;
            }
            send_count++;

            tx_thread_sleep(10);

            /* Receive for the echo-back. */
            status = ux_host_class_cdc_acm_read(p_cdc_acm,  buffer, sizeof(buffer), &actual_length);
            if(status)
            {
                error_count++;
#ifdef SEMI_HOSTING
                if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
                {
                    printf("ux_host_class_cdc_acm_read(for echo-back) failed. err = %ld\n", status);
                }
#endif
                tx_thread_sleep(10);
                continue;
            }
#ifdef SEMI_HOSTING
            if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
            {
                buffer[actual_length-1] = '\0';
                if(buffer[actual_length-2]=='\r')
                {
                    buffer[actual_length-2] = '\0';
                }
                printf("echo-back : %s\n", buffer);
            }
#endif

#ifdef RECEIVE_RESPONSE
            /* Receive for the response. */
            status = ux_host_class_cdc_acm_read(p_cdc_acm,  buffer, sizeof(buffer), &actual_length);
            if(status)
            {
                error_count++;
#ifdef SEMI_HOSTING
                if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
                {
                    printf("ux_host_class_cdc_acm_read(for response) failed. err = %ld\n", status);
                }
#endif
                tx_thread_sleep(10);
                continue;
            }
#ifdef SEMI_HOSTING
            if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
            {
                buffer[actual_length-1] = '\0';
                if(buffer[actual_length-2]=='\r')
                {
                    buffer[actual_length-2] = '\0';
                }
                printf("response  : %s\n", buffer);
            }
#endif
#endif

#ifdef SEMI_HOSTING
            if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
            {
                printf("\n");
            }
#endif

            /* Wait for next command send. */
            tx_thread_sleep(200);
        }
        else
        {
            tx_thread_sleep(10);
        }
    }
}

